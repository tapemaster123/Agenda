# Latam Agenda


## Instalación y ejecución para desarrollo en OS X

El entorno de desarrollo está aislado y autocontenido por medio de contenedores, por lo cual es necesario instalar [Docker](https://www.google.com/search?q=install+docker+os+x).

Luego para levantar los servicios:

  ```
  $ docker-compose -f docker-compose-dev.yml up
  ```

## Instalación y ejecución en producción

La aplicación también puede ser desplegada en producción a través de contenedores Docker. Para ello se requiere instalar [Docker en linux](https://www.google.com/search?q=install+docker+linux).

Para levantar los servicios:

  ```
  $ docker-compose up
  ```
