#!/bin/bash

# Update
sudo apt-get update

# Install git >= 2.3
sudo add-apt-repository -y ppa:git-core/ppa
sudo apt-get update
sudo apt-get install -y git

# Allow receive push to this repo
git config receive.denyCurrentBranch updateInstead

# Install docker
# wget -qO- --no-check-certificate https://get.docker.com/ | sh
curl -sSL https://get.docker.com/gpg | sudo apt-key add -
sudo sh -c "echo deb http://apt.dockerproject.org/repo ubuntu-trusty main > /etc/apt/sources.list.d/docker.list"
sudo apt-get update
sudo apt-get purge lxc-docker*
sudo apt-cache policy docker-engine
sudo apt-get update
sudo apt-get install -y linux-image-extra-$(uname -r)
sudo apt-get install -y docker-engine

# Permisos de ejecucion
sudo usermod -aG docker $USER

# Iniciar demonio
sudo service docker start

# Cerrar sesion y volver a encontrar
exit

# Docker compose
sudo apt-get install python-pip
sudo pip install -U docker-compose
sudo chmod +x /usr/local/bin/docker-compose
