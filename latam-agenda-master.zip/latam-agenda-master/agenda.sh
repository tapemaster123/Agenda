#!/bin/bash

##
# Este script provee una serie de comandos que constituyen
# un 'wrapper' sobre servicios de docker.
##

# Command and args
COMMAND=$1
ARG1=$2
ARG2=$3
ARG3=$4

# CONSTANTS
ZERO="0"
ONE="1"
TWO="2"
THREE="3"
FOUR="4"
FIVE="5"

# Variables
commit=`git rev-parse --short HEAD`
image_name="requies/latam-agenda"

# Container commands
webapp="/home/app/webapp"
set_env="RAILS_ENV=production"
cmd_create="cd $webapp && $set_env $webapp/bin/rake db:create"
cmd_migrate="cd $webapp && $set_env $webapp/bin/rake db:migrate"
cmd_seed="cd $webapp && $set_env $webapp/bin/rake db:seed"
cmd_precompile="cd $webapp && $set_env $webapp/bin/rake assets:precompile"

# Functions

dev_db_restore () {
  path=$1
  echo "Restaurando base de datos '$filename'..."
  gunzip --stdout --suffix zip $path | psql -U postgres
}

db_create () {
  echo "Creando tabla..."
  docker-compose run --rm rails /bin/bash -l -c "$cmd_create"
}

db_migrate () {
  echo "Migrando base de datos..."
  docker-compose run --rm rails /bin/bash -l -c "$cmd_migrate"
}

db_seed () {
  echo "Poblando base de datos..."
  docker-compose run --rm rails /bin/bash -l -c "$cmd_seed"
}

db_bootstrap () {
  db_create
  db_migrate
  db_seed

  echo ""
  echo "Base de datos ha sido inicializada."
}

db_restore () {
  filename=$1
  echo "Restaurando base de datos '$filename'..."
  docker-compose run --rm rails /bin/bash -c "bash /home/app/scripts/docker/restoredb.sh $filename"
}

db_backup () {
  echo "Respaldando base de datos..."
  docker-compose run --rm rails /bin/bash -c "bash /home/app/scripts/docker/backupdb.sh"
}

app_start () {
  echo "Iniciando aplicacion..."
  docker-compose up -d
}

app_stop () {
  echo "Deteniendo aplicacion..."
  docker-compose stop
}

app_restart () {
  echo "Reiniciando aplicacion..."
  docker-compose restart
}

app_deploy () {
  docker-compose build
  docker-compose stop
  docker-compose rm rails
  docker-compose up -d
}

app_enter () {
  echo "Entrando al contener de la aplicación..."
  docker exec -it latam-agenda-$commit bash
}

docker_pull () {
  echo "Descargando dependencias docker..."

  docker pull postgres:9.3
  docker pull phusion/baseimage:0.9.16

  echo ""
  echo "Dependencias descargadas exitosamente"
  echo "Para construir la imagen de la aplicacion ejecute: sh agenda.sh build"
}

docker_build () {
  echo "Construyendo la aplicacion..."

  docker-compose build

  echo ""
  echo "Aplicacion construida"
  echo "Para desplegar la aplicacion ejecute: sh agenda.sh deploy"
}

docker_stop_all_containers () {

  # Numero de contenedores corriendo
  RUNNING_CONTAINERS_COUNT=`docker ps -a -q | wc | awk {'print $1'}`

  # Se detienen todos los procesos que están corriendo
  if [ "$RUNNING_CONTAINERS_COUNT" -gt "$ZERO" ]
  then
    echo "Deteniendo todos los contenedores"
    docker stop $(docker ps -a -q)
  fi
}

docker_destroy_all_containers () {
  docker stop $(docker ps -a -q)
  docker rm $(docker ps -a -q)
}

docker_destroy_unused_images () {
  docker rmi -f $(docker images | grep "<none>" | awk "{print \$3}")
}

print_help () {
    echo "Uso:"
    echo "  sh agenda.sh COMANDO [ARG]"
    echo ""
    echo "Comandos disponibles:"
    echo ""
}

if [ "$COMMAND" = "pull" ]
then

  docker_pull

elif [ "$COMMAND" = "build" ]
then

  docker_build

elif [ "$COMMAND" = "deploy" ]
then

  app_deploy

elif [ "$COMMAND" = "destroy" ]
then

  docker_destroy_all_containers

elif [ "$COMMAND" = "deepdestroy" ]
then

  docker_destroy_all_containers
  docker_destroy_unused_images

elif [ "$COMMAND" = "start" ]
then

  app_start

elif [ "$COMMAND" = "stop" ]
then

  app_stop

elif [ "$COMMAND" = "restart" ]
then

  app_restart

elif [ "$COMMAND" = "enter" ]
then

  app_enter

elif [ "$COMMAND" = "bootstrapdb" ]
then

  db_bootstrap

elif [ "$COMMAND" = "backupdb" ]
then

  db_backup $ARG1

elif [ "$COMMAND" = "restoredb" ]
then

  db_restore $ARG1

elif [ "$COMMAND" = "migrate" ]
then

  db_migrate

elif [ "$COMMAND" = "dev-restoredb" ]
then

  dev_db_restore $ARG1

elif [ "$COMMAND" = "--help" ]
then

  print_help

else
    echo "Comando desconocido"
    echo ""
    print_help
fi
