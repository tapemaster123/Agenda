# Instalacion docker

# Permisos de ejecucion
sudo usermod -aG docker $USER

# Docker compose
sudo apt-get install python-pip
sudo pip install -U docker-compose
sudo chmod +x /usr/local/bin/docker-compose
