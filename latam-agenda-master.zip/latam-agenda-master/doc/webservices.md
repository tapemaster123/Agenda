# Web Services
  - WS-lookup-ticket-user                 -> new agendamiento
  - WS-save-datetime-with-observation     -> agendamiento/reagendamiento
  - WS-update-status-with-observation     -> new link
  - WS-change-status                      -> cerrar agendamiento

# Acciones

Vista nuevo agendamiento:
  - WS: Consulta de ticket con:
    - Nº ticket
    - Email usuario
  - WS: Consulta de datos usuario:
    - Email usuario
    - BP usuario

Creación agendamiento:
  - WS: Grabar en datos complementarios (fecha + hora)
  - WS: Grabar nota "Ticket Agendado por el usuario + Fecha horario"

Creación reagendamiento
- WS: Grabar en datos complementarios (fecha + hora)
- WS: Grabar nota "Ticket Agendado por el usuario + Fecha horario"  

Envío de link a usuario
  - WS: Actualización de ticket: cambiar estado a "Pendiente accion usuario"
  - WS: Agregar nota obligatoria: "se envia url al usuario para agendar"

Agendamiento concluido:
  - WS: actualización de estado a "Resuelto - Nivel 2"



  wsdl = 'http://azuws2014.cloudapp.net/webservicev3/integracao.asmx?WSDL'
  env_namespace = :soapenv
  namespace_identifier = :tem
  client = Savon.client(wsdl: wsdl, env_namespace: env_namespace, namespace_identifier: namespace_identifier)

  # Actualizar agendamiento y dejar una nota
  response = client.call(
    :update_schedule_incident,
    message: {
      'InputObj' => {
        'IncidentNumber' => '926',
        'DateSchedule' => '2015-11-12',
        'HourSchedule' => '11:00',
        'Note' => 'Prueba Danilo'
      }
    }
  )
  puts response.body

  # Buscar la informacion de una persona y caso al mismo tiempo
  response = client.call(
    :lookup_person_case_information,
    message: {
      'InputObj' => {
        'IncidentNumber' => '535',
        'EmailAdress' => 'rafael.willian@cervello.com.br'
      }
    }
  )
  puts response.body
