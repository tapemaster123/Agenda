# Preview all emails at http://localhost:3000/rails/mailers/case_mailer
class CaseMailerPreview < ActionMailer::Preview

end
