require 'test_helper'

class CaseMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
