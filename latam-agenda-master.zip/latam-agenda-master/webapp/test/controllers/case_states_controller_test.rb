require 'test_helper'

class CaseStatesControllerTest < ActionController::TestCase
  setup do
    @case_state = case_states(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:case_states)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create case_state" do
    assert_difference('CaseState.count') do
      post :create, case_state: { case_id: @case_state.case_id, state_id: @case_state.state_id }
    end

    assert_redirected_to case_state_path(assigns(:case_state))
  end

  test "should show case_state" do
    get :show, id: @case_state
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @case_state
    assert_response :success
  end

  test "should update case_state" do
    patch :update, id: @case_state, case_state: { case_id: @case_state.case_id, state_id: @case_state.state_id }
    assert_redirected_to case_state_path(assigns(:case_state))
  end

  test "should destroy case_state" do
    assert_difference('CaseState.count', -1) do
      delete :destroy, id: @case_state
    end

    assert_redirected_to case_states_path
  end
end
