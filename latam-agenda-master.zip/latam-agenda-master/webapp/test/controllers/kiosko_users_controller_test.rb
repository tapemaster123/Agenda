require 'test_helper'

class KioskoUsersControllerTest < ActionController::TestCase
  setup do
    @kiosko_user = kiosko_users(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:kiosko_users)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create kiosko_user" do
    assert_difference('KioskoUser.count') do
      post :create, kiosko_user: { active: @kiosko_user.active, kiosko_id: @kiosko_user.kiosko_id, user_id: @kiosko_user.user_id }
    end

    assert_redirected_to kiosko_user_path(assigns(:kiosko_user))
  end

  test "should show kiosko_user" do
    get :show, id: @kiosko_user
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @kiosko_user
    assert_response :success
  end

  test "should update kiosko_user" do
    patch :update, id: @kiosko_user, kiosko_user: { active: @kiosko_user.active, kiosko_id: @kiosko_user.kiosko_id, user_id: @kiosko_user.user_id }
    assert_redirected_to kiosko_user_path(assigns(:kiosko_user))
  end

  test "should destroy kiosko_user" do
    assert_difference('KioskoUser.count', -1) do
      delete :destroy, id: @kiosko_user
    end

    assert_redirected_to kiosko_users_path
  end
end
