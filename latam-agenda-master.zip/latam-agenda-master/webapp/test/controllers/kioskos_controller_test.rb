require 'test_helper'

class KioskosControllerTest < ActionController::TestCase
  setup do
    @kiosko = kioskos(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:kioskos)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create kiosko" do
    assert_difference('Kiosko.count') do
      post :create, kiosko: { country_id: @kiosko.country_id, enabled: @kiosko.enabled, name: @kiosko.name }
    end

    assert_redirected_to kiosko_path(assigns(:kiosko))
  end

  test "should show kiosko" do
    get :show, id: @kiosko
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @kiosko
    assert_response :success
  end

  test "should update kiosko" do
    patch :update, id: @kiosko, kiosko: { country_id: @kiosko.country_id, enabled: @kiosko.enabled, name: @kiosko.name }
    assert_redirected_to kiosko_path(assigns(:kiosko))
  end

  test "should destroy kiosko" do
    assert_difference('Kiosko.count', -1) do
      delete :destroy, id: @kiosko
    end

    assert_redirected_to kioskos_path
  end
end
