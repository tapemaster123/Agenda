require 'test_helper'

class SchedulingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
