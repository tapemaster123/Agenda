require 'test_helper'

class KioskoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
