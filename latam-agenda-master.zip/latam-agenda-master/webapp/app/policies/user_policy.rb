class UserPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if system_admin?
        scope
      elsif system_manager?
        scope.where(country_id: user.country_id).where("role >= ?", user.role)
      else
        scope.none
      end
    end
  end

  # Overriding Application Policy action methods
  def index?        ; system_admin? || system_manager?            ; end
  def create?       ; system_admin? || system_manager?            ; end
  def show?         ; system_admin? || system_manager? || owner?  ; end
  def update?       ; system_admin? || system_manager? || owner?  ; end
  def destroy?      ; system_admin? || system_manager?            ; end
  def metrics?      ; system_admin? || system_manager?            ; end
  def schedulings?  ; system_admin? || system_manager? || owner?  ; end
  def to_csv?       ; system_admin? || system_manager?            ; end

  def owner?        ; record.id == user.id                        ; end
end
