class ApplicationPolicy
  class Scope
    attr_reader :user, :scope

    def initialize user, scope
        @user = user
        @scope = scope
    end

    def resolve
        scope
    end

    def system_admin?   ; user.present? && user.role == 0    ; end
    def system_manager? ; user.present? && user.role == 10   ; end
    def tech?           ; user.present? && user.role == 20   ; end
    def assistant?      ; user.present? && user.role == 30   ; end
    def anonymous?      ; user.nil?                          ; end
  end

  attr_reader :user, :record

  def initialize user, record
    # raise Pundit::NotAuthorizedError, "Debe estar logueado." unless user
    # raise Pundit::NotAuthorizedError, "Tu cuenta está inactiva." unless user.active?

    @user = user
    @record = record
  end

  # Roles
  def system_admin?   ; user.present? && user.role == 0    ; end
  def system_manager? ; user.present? && user.role == 10   ; end
  def tech?           ; user.present? && user.role == 20   ; end
  def assistant?      ; user.present? && user.role == 30   ; end
  def anonymous?      ; user.nil?                          ; end

  # Actions
  def index?          ; false                                 ; end
  def show?           ; scope.where(id: record.id).exists?    ; end
  def create?         ; false                                 ; end
  def new?            ; create?                               ; end
  def update?         ; false                                 ; end
  def edit?           ; update?                               ; end
  def destroy?        ; false                                 ; end
end