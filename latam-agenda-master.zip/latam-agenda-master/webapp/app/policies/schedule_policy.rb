class SchedulePolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope
    end
  end

  # Overriding Application Policy action methods
  def index?         ; system_admin? || system_manager?  ; end
  def create?        ; system_admin? || system_manager?  ; end
  def show?          ; system_admin? || system_manager?  ; end
  def update?        ; system_admin? || system_manager?  ; end
  def destroy?       ; system_admin? || system_manager?  ; end
  def detail?        ; true                              ; end
  def resume?        ; true                              ; end
  def new_offer?     ; system_admin? || system_manager?  ; end
  def view_offer?    ; true                              ; end
  def create_offer?  ; new_offer?                        ; end
  def to_csv?        ; system_admin? || system_manager?  ; end
end
