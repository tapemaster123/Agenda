class ParameterPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      unless anonymous?
        scope
      else
        scope.none
      end
    end
  end

  # Overriding Application Policy action methods
  def index?    ; system_admin? || system_manager?  ; end
  def create?   ; false  ; end
  def show?     ; system_admin? || system_manager?  ; end
  def update?   ; system_admin? ; end
  def destroy?  ; false  ; end
end
