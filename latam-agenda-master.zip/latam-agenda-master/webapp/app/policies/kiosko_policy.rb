class KioskoPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if system_admin?
        scope
      else
        scope.where(country_id: user.country_id)
      end
    end
  end

  # Overriding Application Policy action methods
  def index?       ; system_admin? || system_manager?  ; end
  def create?      ; system_admin? || system_manager?  ; end
  def show?        ; system_admin? || (system_manager? && same_country?)  ; end
  def update?      ; system_admin? || (system_manager? && same_country?)  ; end
  def destroy?     ; system_admin? || (system_manager? && same_country?)  ; end
  def users?       ; true                              ; end
  def to_csv?      ; system_admin? || system_manager?  ; end


	def same_country?	; user.country_id == record.country_id ; end
end
