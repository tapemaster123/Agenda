class CasePolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      unless anonymous?
        scope
      else
        scope.none
      end
    end
  end

  # Overriding Application Policy action methods
  def index?          ; system_admin? || system_manager?           ; end
  def create?         ; true                                       ; end
  def show?           ; system_admin? || system_manager? || tech?  ; end
  def update?         ; true                                       ; end
  def destroy?        ; system_admin? || system_manager?           ; end
  def search?         ; not anonymous?                             ; end
  def new_link?       ; not anonymous?                             ; end
  def send_link?      ; new_link?                                  ; end
  def new_reschedule? ; true                                       ; end
  def reschedule?     ; true                                       ; end
  def change_state?   ; system_admin? || system_manager? || tech?  ; end
  def add_state?      ; change_state?                              ; end
  def edit_tech?      ; system_admin? || system_manager? || tech?  ; end
  def change_tech?    ; edit_tech?                                 ; end
  def to_csv?         ; index?                                     ; end
end
