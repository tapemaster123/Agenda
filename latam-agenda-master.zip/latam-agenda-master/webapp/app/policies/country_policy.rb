class CountryPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if system_admin?
        scope
      else
        scope.where(id: user.country_id)
      end
    end
  end

  # Overriding Application Policy action methods
  def index?       ; system_admin? || system_manager?  ; end
  def create?      ; system_admin?                     ; end
  def show?        ; system_admin?                     ; end
  def update?      ; system_admin?                     ; end
  def destroy?     ; system_admin?                     ; end
  def kioskos?     ; true                              ; end
end
