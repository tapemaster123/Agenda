class StatePolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      scope
    end
  end

  # Overriding Application Policy action methods
  def index?    ; system_admin? || system_manager?  ; end
  def create?   ; false  ; end
  def show?     ; system_admin? || system_manager?  ; end
  def update?   ; false  ; end
  def destroy?  ; false  ; end
end
