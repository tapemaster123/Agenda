class ObservationPolicy < ApplicationPolicy
  class Scope < Scope
    def resolve
      if system_admin? || system_manager?
        scope
      elsif not anonymous?
        scope.where(user_id: user.id)
      else
        scope.none
      end
    end
  end

  # Overriding Application Policy action methods
  def index?    ; not anonymous?                              ; end
  def create?   ; not anonymous?                              ; end
  def show?     ; system_admin? || system_manager? || owner?  ; end
  def update?   ; system_admin? || system_manager? || owner?  ; end
  def destroy?  ; system_admin? || system_manager? || owner?  ; end
  def to_csv?   ; system_admin? || system_manager?            ; end

  def owner?    ; record.user_id == user.id                   ; end
end