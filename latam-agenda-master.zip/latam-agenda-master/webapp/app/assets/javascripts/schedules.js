// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

// Obtener listado de kioskos de un pais con ajax
function requestKioskos (country_id) {
  $.ajax({
    async: true,
    type: 'get',
    url: '/countries/' + country_id + '/kioskos.json',
    success: function (data) {
      var promptContent = $('.prompt-content')
      if (data.length > 0) {
        $('#kiosko option:eq(0)').html(promptContent.data('prompt'))
        $.each(data, function(index, item) {
          $('#kiosko').append($('<option>', {
            value: item.id,
            text : item.name
          }))
        })
      }
      else {
        $('#kiosko option:eq(0)').html(promptContent.data('empty'))
      }
    },
    timeout:10000,
    error: function (jqXHR, textStatus, errorThrown) {

    }
  })
}

// Obtener listado de usuarios de un kiosko con ajax
function requestUsers (kiosko_id) {
  $.ajax({
    async: true,
    type: 'get',
    url: '/kioskos/' + kiosko_id + '/users.json',
    success: function (data) {
      var promptContent = $('.prompt-content')
      if (data.length > 0) {
        //$('#users option:eq(0)').html(promptContent.data('prompt'))
        $.each(data, function(index, item) {
          $('#users').append($('<option>', {
            value: item.id,
            text : item.name
          }))
        })
        $("#users").trigger("chosen:updated");
      }
      else {
        //$('#users option:eq(0)').html(promptContent.data('empty'))
      }
    },
    timeout:10000,
    error: function (jqXHR, textStatus, errorThrown) {

    }
  })
}

// Validaciones de rangos horarios de oferta y almuerzo
function timerangeValidator (timeIni, timeEnd, event) {
  var timeDiffInMs = timeEnd - timeIni
  var slotSizeInMs = getSlotSize() * 1000 * 60

  // Valida que la hora de inicio sea menor que la de termino
  if (timeDiffInMs <= 0) {
    alert(I18n.t('error_range_start', { scope: 'js.schedules' }))
    event.preventDefault()
  }

  // Valida que el tamaño de slot quepa en el rango horario seleccionado
  else if (timeDiffInMs < slotSizeInMs) {
    alert(I18n.t('error_range_size', { scope: 'js.schedules' }))
    event.preventDefault()
  }

  // Valida que el rango escogido sea compatible con rango de oferta
  else if (timeIni < $('#datepair-offer .start').timepicker('getTime') ||
    timeEnd > $('#datepair-offer .end').timepicker('getTime')) {
    alert(I18n.t('error_range_lunch', { scope: 'js.schedules' }))
    event.preventDefault()
  }
}

// Obtiene tamaño de slot como entero
var getSlotSize = function() {
  return parseInt($('#slot_size option:selected').val())
}

var getLocaleRanges = function() {
  var ranges = {}
  if (I18n.currentLocale() == 'es-CL') {
    ranges = {
     'Esta semana': [moment(), moment().endOf('isoweek')],
     'Próxima semana': [moment().add(1, 'week').startOf('isoweek'), moment().add(1, 'week').endOf('isoweek')],
     'Este mes': [moment(), moment().endOf('month')],
     'Próximo mes': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')],
     'Próximos 3 meses': [moment().add(1, 'month').startOf('month'), moment().add(3, 'month').endOf('month')],
     'Este año': [moment(), moment().endOf('year')]
    }
  }
  else if (I18n.currentLocale() == 'pt-BR') {
    ranges = {
     'Esta semana': [moment(), moment().endOf('isoweek')],
     'Próxima semana': [moment().add(1, 'week').startOf('isoweek'), moment().add(1, 'week').endOf('isoweek')],
     'Este mês': [moment(), moment().endOf('month')],
     'Próximo mês': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')],
     'Próximos 3 meses': [moment().add(1, 'month').startOf('month'), moment().add(3, 'month').endOf('month')],
     'Este ano': [moment(), moment().endOf('year')]
    }
  }
  else {
    ranges = {
     'This week': [moment(), moment().endOf('isoweek')],
     'Next week': [moment().add(1, 'week').startOf('isoweek'), moment().add(1, 'week').endOf('isoweek')],
     'This month': [moment(), moment().endOf('month')],
     'Next month': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')],
     'Next 3 months': [moment().add(1, 'month').startOf('month'), moment().add(3, 'month').endOf('month')],
     'This year': [moment(), moment().endOf('year')]
    }
  }
  return ranges
}

$(function() {
  // Prompt de paises y kioskos
  $('#country option:eq(0), #kiosko option:eq(0)').html($('.prompt-content').data('prompt'))

  // Si select de paises cambia se filtran kioskos
  $('#country').on('change', function() {
    $('#kiosko option:eq(0), #users option:eq(0)').html('')
    $("#kiosko option:gt(0), #users option:gt(0)").remove()
    $("#users").trigger("chosen:updated");

    var value = $(this).val()
    if (value > 0) {
      requestKioskos(value);
    }
  })

  // Si select de kioskos cambia se filtran usuarios
  $("#kiosko").on('change', function() {
    $('#users option:eq(0)').html('')
    $("#users option:gt(0)").remove()
    $("#users").trigger("chosen:updated");

    var value = $(this).val()
    if (value > 0) {
      requestUsers(value);
    }
  })

  // Si slot_size cambia, se actualizan los slots de ofertas (se puede mejorar)
  // También se actualizan los slots de almuerzo
  $('#slot_size').on('change', function() {
    $('#datepair-offer .time, #datepair-lunch .time').timepicker('option', {
      step: getSlotSize()
    })
  })

  // Validar campos antes de hacer submit
  $('#new_offer_schedules').on('submit', function(event) {
    // Verifica que se haya elegido al menos un técnico
    if ($("#users").chosen().val() == null) {
      alert(I18n.t('techs_not_selected', { scope: 'js.schedules' }))
      event.preventDefault()
    }

    // Verifica que se haya elegido al menos un día de la semana en formulario
    else if ($("input:checkbox[name='schedule[week_days][]']:checked").length == 0) {
      alert(I18n.t('weekday_not_selected', { scope: 'js.schedules' }))
      event.preventDefault()
    }

    else {
      // Validacione de rango de tiempo de oferta
      timerangeValidator(
        $('#datepair-offer .start').timepicker('getTime'),
        $('#datepair-offer .end').timepicker('getTime'),
        event
      );

      // Validaciòn de rango de tiempo de almuerzo
      if ($('#with_lunchtime').is(':checked')) {
        timerangeValidator(
          $('#datepair-lunch .start').timepicker('getTime'),
          $('#datepair-lunch .end').timepicker('getTime'),
          event
        );
      }
    }
  })

  // Si checkbox de lunchtime cambia se verifica que haya rango horario escogido
  // Y se muestra u oculta el rango horario para almuerzo
  $('#with_lunchtime').on('change', function() {
    if ($('#schedule_start').val() != 0 && $('#schedule_end').val() != 0) {
      if ($(this).is(':checked')) {
        $('#datepair-lunch').removeClass('hidden')
        $('#start_lunch, #end_lunch').prop('required', true)
        $('#datepair-lunch .time').timepicker('option', {
          minTime: $('#schedule_start').val(),
          maxTime: $('#schedule_end').val()
        })
      }
      else {
        $('#datepair-lunch').addClass('hidden')
        $('#start_lunch, #end_lunch').prop('required', false)
      }
    }
    else {
      alert(I18n.t('range_not_selected', { scope: 'js.schedules' }))
      $(this).prop('checked', false)
      $('#datepair-lunch').addClass('hidden')
    }
  })

  // Si cambian los inputs de timerange se actualiza el rango horario disponible para almuerzo
  $('#schedule_start, #schedule_end').on('changeTime', function() {
    $('#datepair-lunch .time').timepicker('option', {
      minTime: $('#schedule_start').val(),
      maxTime: $('#schedule_end').val()
    })
  })

  //var i18nRanges =

  // Date range picker with predefined ranges
  $('#daterange').daterangepicker({
    autoApply: true,
    minDate: moment(),
    startDate: moment().add(1, 'day'),
    endDate: moment().endOf('isoweek'),
    showWeekNumbers: true,
    ranges: getLocaleRanges(),
    locale: {
      format: I18n.t('daterange_format', { scope: 'js.schedules' }),
      applyLabel: I18n.t('apply_label', { scope: 'js.schedules' }),
      cancelLabel: I18n.t('cancel_label', { scope: 'js.schedules' }),
      customRangeLabel: I18n.t('custom_range_label', { scope: 'js.schedules' }),
      firstDay: 1
    }
  })

  // Time picker to offer (datepair)
  $('#datepair-offer .time').timepicker({
    step: getSlotSize(),
    minTime: '6am',
    maxTime: '11pm',
    showDuration: true,
    timeFormat: 'H:i',
    disableTimeRanges: [
      ['12am', '6am'],
      ['23pm', '12am']
    ]
  })
  $('#datepair-offer').datepair({
    'defaultTimeDelta': 0
  })

  // Time picker to lunch (datepair)
  $('#datepair-lunch .time').timepicker({
    step: 30,
    minTime: '6am',
    maxTime: '11pm',
    showDuration: true,
    timeFormat: 'H:i',
    disableTimeRanges: [
      ['12am', '6am'],
      ['23pm', '12am']
    ]
  })
  $('#datepair-lunch').datepair({
    'defaultTimeDelta': 0
  })

  // Users multiple select with chosen
  $('#users').chosen({
    placeholder_text_multiple: $('.prompt-content').data('prompt'),
    no_results_text: $('.prompt-content').data('empty')
  })

})
