// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

function displayCalendar(schedulings) {

  // Calendar
  var minDate = moment()
      maxDate = moment().add(8, 'weeks');

  var agenda = {}

  $('#tech-schedulings-calendar').fullCalendar({
    firstDay: 1,
    timezone: 'UTC',
    lang: I18n.currentLocale(),
    header: {
      left: 'prev,next today',
      center: 'title',
      right: 'month,agendaWeek,agendaDay'
    },

    events: schedulings,

    dayRender: function (momentDate, $cell){
      var today = minDate.utc()
      var day = momentDate.utc()

      if (momentDate > maxDate) {
        $cell.addClass('fc-state-disabled');
      }
      else if (momentDate < minDate) {
        $cell.addClass('fc-state-disabled');
      }
    },

    viewRender: function(currentView) {

      // Past
      if (minDate >= currentView.start && minDate <= currentView.end) {
        $(".fc-prev-button").prop('disabled', true);
        $(".fc-prev-button").addClass('fc-state-disabled');
      }
      else {
        $(".fc-prev-button").removeClass('fc-state-disabled');
        $(".fc-prev-button").prop('disabled', false);
      }

      // Future
      if (maxDate >= currentView.start && maxDate <= currentView.end) {
        $(".fc-next-button").prop('disabled', true);
        $(".fc-next-button").addClass('fc-state-disabled');
      } else {
        $(".fc-next-button").removeClass('fc-state-disabled');
        $(".fc-next-button").prop('disabled', false);
      }
    }

  })
}

function requestUserCases (user_id) {
  $.ajax({
    async: true,
    type: 'get',
    url: '/schedulings/detail.json',
    data: {user_id: user_id},
    success: function (data) {
      var schedulings = []
      data.forEach(function(scheduling) {
        schedulings.push({
          id: scheduling.id,
          title: 'Ticket #' + scheduling.case.ticket,
          start: scheduling.schedule.date + " " + moment(scheduling.schedule.start).utc().format("HH:mm"),
          end: scheduling.schedule.date + " " + moment(scheduling.schedule.end).utc().format("HH:mm"),
          url: scheduling.url
        })
      })

      // Se obtiene el detalle por caso
      displayCalendar(schedulings)
    },
    timeout:10000,
    error: function (jqXHR, textStatus, errorThrown) {
    }
  })
}

$(function () {

  if ($('#tech-id').size() > 0) {
    var userId = $('#tech-id').data('user-id')
    requestUserCases(userId)
  }
})
