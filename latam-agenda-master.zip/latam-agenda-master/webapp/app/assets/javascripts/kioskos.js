// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

$(document).on('ready', function () {
  $('#techs-select').chosen({
    placeholder_text_multiple: I18n.t('chosen_placeholder_text_multiple', {scope: 'js.kioskos'}),
    no_results_text: I18n.t('chosen_no_results_text', {scope: 'js.kioskos'})
  })
})
