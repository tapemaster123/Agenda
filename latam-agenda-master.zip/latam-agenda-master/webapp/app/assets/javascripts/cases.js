// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
function displayCalendar(schedules) {
  // console.log(schedules)

  // Calendar
  var min_date = moment(),
      max_date = moment().add(8, 'weeks');

  var agenda = {}

  $('#calendar').fullCalendar('destroy')
  $('#calendar').fullCalendar({
    firstDay: 1,
    header: {
      left: 'prev',
      center: 'title',
      right: 'next'
    },
    height: 500,
    timezone: 'UTC',
    lang: I18n.currentLocale(),

    dayClick: function (date, jsEvent, view) {
      var kiosko_id = $('#kiosko-select').val()
      var day_str = date.utc().format("YYYY-MM-DD")

      if (agenda[day_str] == 'available') {
        requestDaySchedules(kiosko_id, day_str)
      }
      else {
        alert(I18n.t('day_not_available', {scope: 'js.cases' } ) + ' ' + date.utc().format("YYYY-MM-DD"))
      }
    },

    dayRender: function(moment_date, $cell) {
      var today = min_date.utc()
      var day = moment_date.utc()
      var today_str = today.format("YYYY-MM-DD")
      var day_str = day.format("YYYY-MM-DD")

      // Se busca la fecha en los schedules
      var day_in_schedules = false
      schedules.forEach(function (schedule) {
        if (schedule.date == day_str) {
          day_in_schedules = true
          if ((schedule.num_available > schedule.num_taken) &&
              (schedule.date != today_str)) {
            $cell.addClass('fc-available available')
            agenda[day_str] = 'available'
          }
          else if ((schedule.num_available > schedule.num_taken) &&
                   (schedule.date == today_str)) {
            agenda[day_str] = 'available'
          }
          else {
            $cell.addClass('fc-no-available no-available')
            agenda[day_str] = 'no-available'
          }
        }
      })

      if (!day_in_schedules) {
        if (day >= today) {
          $cell.addClass('fc-no-available no-available')
          agenda[day_str] = 'no-available'
        }
      }
    },

    viewRender: function(currentView) {

      // Past
      if (min_date >= currentView.start && min_date <= currentView.end) {
        console.log('Min date: ' + new Date(min_date))
        console.log('Current view start: ' + new Date(currentView.start))

        $(".fc-prev-button").prop('disabled', true);
        $(".fc-prev-button").addClass('fc-state-disabled');
      }
      else {
        $(".fc-prev-button").removeClass('fc-state-disabled');
        $(".fc-prev-button").prop('disabled', false);
      }

      // Future
      if (max_date >= currentView.start && max_date <= currentView.end) {
        $(".fc-next-button").prop('disabled', true);
        $(".fc-next-button").addClass('fc-state-disabled');
      } else {
        $(".fc-next-button").removeClass('fc-state-disabled');
        $(".fc-next-button").prop('disabled', false);
      }
    }
  })

}

function requestResume (kiosko_id) {
  $.ajax({
    async: true,
    type: 'get',
    url: '/schedules/resume',
    data: {kiosko_id: kiosko_id},
    success: function (data) {
      $('#calendar-section').slideDown(100, function () {
        displayCalendar(data.schedules)
      })
    },
    timeout:10000,
    error: function (jqXHR, textStatus, errorThrown) {

    }
  })
}

function requestDaySchedules (kiosko_id, date, cb) {
  $.ajax({
    async: true,
    type: 'get',
    url: '/schedules/detail',
    data: {kiosko_id: kiosko_id, date: date},
    success: function (data) {

      // Se actualiza la fecha en el input
      $('#schedule-date').val(date)

      // Se actualiza el texto de detalle
      $('#time-window-detail').html(renderDateText(date))

      // Se obtiene el detalle por hora)
      displayDayDetail(data.schedules, cb)
    },
    timeout:10000,
    error: function (jqXHR, textStatus, errorThrown) {

    }
  })
}

function displayDayDetail (schedules, cb) {
  var $detail = $('#day-detail')
  $detail.html('')

  schedules.forEach(function (schedule) {
    appendTimeWindow($detail, schedule)
  })

  if (cb)
    cb()
}

function appendTimeWindow ($detail, schedule) {
  var start_str = moment(schedule.start).utc().format('HH:mm:ss')
  var end_str = moment(schedule.end).utc().format('HH:mm:ss')

  var status = undefined
  if (schedule.num_available > schedule.num_taken)
    status = 'available'
  else
    status = 'no-available'

  $detail.append(renderRadioButton(status, start_str, end_str))
}

function renderRadioButton(status, start_str, end_str) {
  var value = start_str + '-' + end_str
  return [
    '<tr class="', status,'">',
      '<td>',
        '<input class="', status,'" type="radio" name="schedule[time_window]" required="required" value="', value ,'">',
      '</td>',
      '<td>', start_str, ' - ', end_str, '</td>',
    '</tr>'
  ].join('')
}

function renderDateText (date) {
  var d = moment(date).utc().format("YYYY-MM-DD")
  return I18n.t('time_windows_available', {scope: 'js.cases' } ) + ' ' + d + '<br>' +
         '(' + I18n.t('kiosko_local_time', {scope: 'js.cases' } ) + ' ' + ')'
}

function appendTimeToAgendamiento (tw) {
  var $input = $('#schedule-date')
  var date = $input.val().split(' ')[0]
  $input.val(date + ' ' + tw)
}

$(document).on('ready', function () {

  // Events
  $('#kiosko-select').on('change', function () {
    var value = $(this).val()
    if (value) {
      requestResume(value)
    }
    else {
      $('#calendar-section').slideUp(0)
    }
  }).trigger('change')

  // $('.case-input').on('keyup', function () {
  //   var are_filled = true
  //   $('.case-input').each(function () {
  //       if ($(this).val() == '')
  //           are_filled = false
  //   })
  //   if (are_filled) {
  //     $('#kiosko-section').slideDown(100)
  //   }
  //   else {
  //     $('#kiosko-section').slideUp(100)
  //   }
  // })

  $(document).on('change', 'input[type=radio][name="schedule[time_window]"]', function () {
    var value = $(this).val()
    appendTimeToAgendamiento(value)
  })

  $(document).on('click', 'input.no-available[type=radio][name="schedule[time_window]"]', function (e) {
    e.preventDefault()
    alert(I18n.t('time_window_not_available', { scope: 'js.cases' } ) + ' ')
  })

  // Tiene un valor ya definido?
  var $schedule_date = $('#schedule-date')
  if ($schedule_date.val() != '') {
    var kiosko_id = $('#kiosko-select').val()
    var day_str = $schedule_date.val().split(' ')[0]
    var tw = $schedule_date.val().split(' ')[1]

    requestDaySchedules(kiosko_id, day_str, function () {
      var selector = 'input[type=radio]'
      selector += '[name="schedule[time_window]"]'
      selector += '[value="' + tw + '"]'
      $(selector).prop('checked', true)
      appendTimeToAgendamiento(tw)
    })
  }
})
