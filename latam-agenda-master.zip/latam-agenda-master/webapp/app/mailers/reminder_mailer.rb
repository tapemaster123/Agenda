class ReminderMailer < ApplicationMailer
  default from: Rails.application.config.action_mailer.default_options[:from]

  def send_reminder(params)
    @ticket = params[:ticket]
    @bp = params[:bp]
    @email = params[:email]
    subject = t('subject', scope: [:mailer, :reminder], ticket: @ticket)

    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/latam-email.png')
    mail(to: @email, subject: subject)
  end
end
