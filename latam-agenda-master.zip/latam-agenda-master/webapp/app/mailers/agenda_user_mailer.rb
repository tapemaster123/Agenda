class AgendaUserMailer < Devise::Mailer   
  
  # Gives access to all helpers defined within `application_helper`.
  helper :application 
  
  # Optional. eg. `confirmation_url`
  include Devise::Controllers::UrlHelpers
  
  # To make sure that your mailer uses the devise views
  default template_path: 'devise/mailer' 

  # Override reset password instructions method to add attachments
  def reset_password_instructions(record, token, opts={})
    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/lan-tam-email.png')
    super
  end

end