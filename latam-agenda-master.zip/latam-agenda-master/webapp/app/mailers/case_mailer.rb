class CaseMailer < ApplicationMailer
  default from: Rails.application.config.action_mailer.default_options[:from]

  def case_confirmation(case_id)
    @case = Case.find(case_id)
    subject = t('subject', scope: [:mailer, :confirmation], ticket: @case.ticket)

    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/latam-email.png')
    mail(to: @case.email, subject: subject)
  end

  def case_reconfirmation(case_id)
    @case = Case.find(case_id)
    subject = t('subject', scope: [:mailer, :reconfirmation], ticket: @case.ticket)

    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/latam-email.png')
    mail(to: @case.email, subject: subject)
  end

  def case_reminder(case_id)
    @case = Case.find(case_id)
    subject = t('subject', scope: [:mailer, :case_reminder], ticket: @case.ticket)

    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/latam-email.png')
    mail(to: @case.email, subject: subject)
  end

  def case_observation(case_id, observation_id)
    @case = Case.find(case_id)
    @observation = Observation.find(observation_id)
    subject = t('subject', scope: [:mailer, :observation], ticket: @case.ticket)

    attachments.inline['logo-latam.png'] = File.read('./app/assets/images/latam-email.png')
    mail(to: @case.email, subject: subject)
  end
end
