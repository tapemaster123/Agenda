class SyncObservationWorker
  include Sidekiq::Worker

  def perform(observation_id)
    logger.info "[SyncObservationWorker]"

    # Sync only when app is in production mode
    return true unless Rails.env.production?

    observation = Observation.find(observation_id)
    client = Savon.client(
      wsdl: Parameter.find_by_key('WS_WSDL').value,
      env_namespace: Parameter.find_by_key('WS_ENV_NAMESPACE').value,
      namespace_identifier: Parameter.find_by_key('WS_NAMESPACE_IDENTIFIER').value
    )

    response = client.call(
      :update_case_work_log,
      message: {
        'InputObj' => {
          'Description' => observation.observation,
          'EmailAddress' => observation.case.email,
          'IncidentNumber' => observation.case.ticket,
          'PublicAccess' => '1'
        }
      }
    )
  end
end
