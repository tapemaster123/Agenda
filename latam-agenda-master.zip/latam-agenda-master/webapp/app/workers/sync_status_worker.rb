class SyncStatusWorker
  include Sidekiq::Worker

  def perform(case_id, tech_name)
    logger.info "[SyncStatusWorker]"

    # Sync only when app is in production mode
    return true unless Rails.env.production?

    _case = Case.find(case_id)
    client = Savon.client(
      wsdl: Parameter.find_by_key('WS_WSDL').value,
      env_namespace: Parameter.find_by_key('WS_ENV_NAMESPACE').value,
      namespace_identifier: Parameter.find_by_key('WS_NAMESPACE_IDENTIFIER').value
    )

    status = _case.state
    remote_status = status.remote_status
    remote_resolution_method = status.remote_resolution_method || ""
    # No traducir "No Determinado"
    remote_cause = (remote_resolution_method == "")? "" : "No Determinado"
    response = client.call(
      :update_incident_status_schedule,
      message: {
        'InputObj' => {
          'IncidentNumber' => _case.ticket,
          'Status' => remote_status,
          'Note' => "El técnico '#{tech_name}' ha cambiado el status a '#{status}'",
          'ResolutionMethod' => remote_resolution_method,
          'Cause' => remote_cause
        }
      }
    )
  end
end
