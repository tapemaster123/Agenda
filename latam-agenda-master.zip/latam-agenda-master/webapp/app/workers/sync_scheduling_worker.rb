class SyncSchedulingWorker
  include Sidekiq::Worker

  def perform(case_id)
    logger.info "[SyncSchedulingWorker]"

    # Sync only when app is in production mode
    return true unless Rails.env.production?

    _case = Case.find(case_id)
    client = Savon.client(
      wsdl: Parameter.find_by_key('WS_WSDL').value,
      env_namespace: Parameter.find_by_key('WS_ENV_NAMESPACE').value,
      namespace_identifier: Parameter.find_by_key('WS_NAMESPACE_IDENTIFIER').value
    )

    # Actualizar agendamiento y dejar una nota
    ticket = _case.ticket
    kiosko = _case.get_kiosco
    tech = _case.get_assigned_employee
    date = _case.get_booked_date.to_s
    tw = _case.get_booked_time_window
    start = _case.get_booked_start
    # note = I18n.t('scheduling_note', scope: :cervello, kiosko: kiosk, tech: tech, tw: tw, date: date)
    # Esto debe quedar en chileno po loco!
    note = "Incidente agendado en el kiosco '#{kiosko}' para el técnico '#{tech}' en el bloque '#{tw}' el día '#{date}'"
    response = client.call(
      :update_schedule_incident,
      message: {
        'InputObj' => {
          'IncidentNumber' => ticket,
          'DateSchedule' => date,
          'HourSchedule' => start,
          'Note' => note,
          'AnalystEmail' => tech.email
        }
      }
    )

    body = response.body
    remote_information = body.try(:[], :update_schedule_incident_response)
                             .try(:[], :update_schedule_incident_result)

    if remote_information.nil?
      raise I18n.t('not_response', scope: :cervello)
    end

    # TODO: Borrar esta mitigacion que debe ser solucionada por Cervello
    # Mitigacion dejara de funcionar el 8 de septiembre de 2016 automaticamente
    # Se extiende mitigacion hasta el 8 de diciembre de 2016
    # Se extiende mitigacion hasta el 8 de abril de 2017
    # Se extiende mitigacion hasta el 8 de abril de 2022
    if Date.today < Date.parse('2022-04-08')
      # Se agrega un delay ya que cervello no es capaz de calcular bien los SLA
      # Si las operaciones de cambio de status ocurren en el mismo minuto
      sleep(62)
      response = client.call(
        :update_incident_status_schedule,
        message: {
          'InputObj' => {
            'IncidentNumber' => ticket,
            'Status' => 'Pendiente - Acción Usuario',
            'Note' => "agendamientoit.lan.com regresa el ticket a estado Pendiente (Bug Cervello)",
            'ResolutionMethod' => "",
            'Cause' => ""
          }
        }
      )
    end
  end
end
