class CancelTicketWorker
  include Sidekiq::Worker

  def perform(ticket)
    logger.info "[CancelTicketWorker]: #{ticket}"

    # Sync only when app is in production mode
    return true unless Rails.env.production?

    client = Savon.client(
      wsdl: Parameter.find_by_key('WS_WSDL').value,
      env_namespace: Parameter.find_by_key('WS_ENV_NAMESPACE').value,
      namespace_identifier: Parameter.find_by_key('WS_NAMESPACE_IDENTIFIER').value
    )

    # FIXME
    # Se ha cambiado desde Cancelado a Cerrado, el archivo y clase deberían renombrarse
    remote_status = 'Cerrado - Sin Respuesta Usuario'
    remote_resolution_method = 'Cerrado - Sin Respuesta Usuario'
    # No traducir "No Determinado"
    remote_cause = (remote_resolution_method == "")? "" : "No Determinado"
    response = client.call(
      :update_incident_status_schedule,
      message: {
        'InputObj' => {
          'IncidentNumber' => ticket,
          'Status' => remote_status,
          'Note' => "Automatically closed by agendamientoit.lan.com",
          'ResolutionMethod' => remote_resolution_method,
          'Cause' => remote_cause
        }
      }
    )
  end
end
