class KioskosController < ApplicationController
  before_action :set_kiosko, only: [:show, :edit, :update, :destroy, :users]
  before_action :authorize_kioskos, only: [:new, :create, :index]

  # GET /kiosko/1/users.json
  def users
    # Solo usuarios tecnicos y activos
    @users = @kiosko.users.techs.enabled

    respond_to do |format|
      format.json
    end
  end

  # GET /kioskos
  def index
    @page = params[:page]

    kioskos_filtered = params[:q].present? ? policy_scope(Kiosko).by_name(params[:q]) : policy_scope(Kiosko).all

    kioskos_filtered = kioskos_filtered
                        .includes(:country)
                        .order('countries.name ASC', 'kioskos.name ASC')
    @kioskos = kioskos_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(Kiosko).to_csv?
          end_data Kiosko.to_csv, filename: "Kioskos-#{Time.now.to_s(:number)}.csv"
        else
          flash[:error] = t('not_authorized', scope: :pundit)
          redirect_to kioskos_path
        end
      }
    end
  end

  # GET /kioskos/1
  def show
  end

  # GET /kioskos/new
  def new
    @kiosko = Kiosko.new
    @kiosko.country_id = current_user.country_id unless current_user.system_admin?
  end

  # GET /kioskos/1/edit
  def edit
  end

  # POST /kioskos
  def create
    @kiosko = Kiosko.new(kiosko_params)
    @kiosko.country_id = current_user.country_id unless current_user.system_admin?

    if @kiosko.save
      redirect_to @kiosko, notice: t('success_on_model_action',
                            scope: :crud_views,
                            resource: t('one', scope: [:activerecord, :models, :kiosko]),
                            action: t('participle', scope: [:actions, :create]))
    else
      render :new
    end
  end

  # PATCH/PUT /kioskos/1
  def update
    if @kiosko.update(kiosko_params)
      redirect_to @kiosko, notice: t('success_on_model_action',
                            scope: :crud_views,
                            resource: t('one', scope: [:activerecord, :models, :kiosko]),
                            action: t('participle', scope: [:actions, :update]))
    else
      render :edit
    end
  end

  # DELETE /kioskos/1
  def destroy
    if @kiosko.destroy
      redirect_to kioskos_url, notice: t('success_on_model_action',
                                scope: :crud_views,
                                resource: t('one', scope: [:activerecord, :models, :kiosko]),
                                action: t('participle', scope: [:actions, :delete]))
    else
      render :show
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_kiosko
      @kiosko = Kiosko.find(params[:id])
      authorize @kiosko
    end

    # Authorization for class.
    def authorize_kioskos
      authorize Kiosko
    end

    # Only allow a trusted parameter "white list" through.
    def kiosko_params
      if current_user.system_admin?
        params.require(:kiosko).permit(:name, :location, :map_url, :enabled, :country_id, :user_ids => [])
      else
        params.require(:kiosko).permit(:name, :enabled, :user_ids => [])
      end
    end
end
