class CasesController < ApplicationController
  before_action :set_case, only: [:show, :edit, :update, :destroy, :change_state, :add_state, :edit_tech, :change_tech]
  before_action :authorize_cases, only: [:new, :create, :index, :new_reschedule, :reschedule]
  skip_before_filter :authenticate_user!, only: [:new, :create, :new_reschedule, :reschedule, :update]

  # GET /cases
  def index
    @page = params[:page]

    cases_filtered = params[:q].present? ? Case.includes(:kiosko, :schedule).by_ticket(params[:q]) : Case.includes(:kiosko, :schedule).all

    @cases = cases_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(Case).to_csv?
          send_data Case.includes(:country, :kiosko, :status)
                        .to_csv, filename: "Cases-#{Time.now.to_s(:number)}.csv"
        else
          flash.now[:error] = t('not_authorized', scope: :pundit)
          redirect_to cases_path
        end
      }
    end
  end

  # GET /cases/by_kiosko_datetime
  def by_kiosko_datetime
    kiosko_user_ids = KioskoUser
                       .where(:kiosko_id => params[:kiosko_id])
                       .pluck(:id)

    schedules = Schedule
                .where(:kiosko_user_id => kiosko_user_ids)
                .where(:date => params[:schedule_date])
                .where(:start => params[:schedule_start])
                .where(:end => params[:schedule_end])
                .where(:taken => 1)
                .includes(:case)

    cases = []
    schedules.each do |schedule|
      cases.push(schedule.case)
    end

    render json: {
      cases: cases
    }, status: 200
  end

  # GET /cases/1
  def show
    @scheduling = @case.scheduling
  end

  # GET /cases/new
  def new
    new_params = params[:case].nil? ? Hash.new : case_params
    @lock_form = (new_params == Hash.new) ? false : true

    @case = Case.new(new_params)
  end

  # GET /cases/1/edit
  def edit
    scheduling = @case.scheduling
    if not scheduling.nil?
      @schedule = scheduling.schedule
      @kiosko = @schedule.kiosko_user.kiosko
    end
  end

  # POST /cases
  def create

    # Los parametros de fecha deben ser validos antes de proseguir
    if not schedule_params_valid
      @case = Case.new(case_params)
      flash.now[:error] = t('time_window_selected', scope: :errors)
      return render :new
    end

    # variables
    kiosko_id = kiosko_params[:id]
    schedule_date = schedule_params[:date]
    schedule_start = schedule_params[:start]
    schedule_end = schedule_params[:end]

    # Caso nuevo sin guardar
    @case = Case.new(case_params)

    # Se intenta sincronizar los datos desde Cervello
    case_fetched = @case.fetch_case_person_information

    # Se obtiene el kiosko
    @kiosko = Kiosko.find(kiosko_id)

    # Se intenta obtener el analista asignado por cervello
    analyst_id = User.try(:find_by_email, @case.ws_ticket_analyst_email)
                     .try(:read_attribute, :id)

    # Se obtiene una agenda disponible para el caso
    @schedule = Schedule.select_for_new_case(kiosko_id, analyst_id,
                                                        schedule_date,
                                                        schedule_start,
                                                        schedule_end)

    if not case_fetched
      return render :new
    end

    # Aun esta disponible la agenda?
    if @schedule

      # Se guarda el caso, la agenda y el agendamiento
      case_saved = @case.save_with_scheduling(@schedule)

      # Se elimina el recordatorio
      Reminder.try_deactivate(case_params)

      if case_saved
        @case.send_confirmation
        SyncSchedulingWorker.perform_async(@case.id)
        render :confirmation
      else
        render :new
      end
    else
      flash.now[:error] = t('time_window_taken', scope: :errors)
      render :new
    end
  end

  # PATCH/PUT /cases/1
  def update

    # Los parametros de fecha deben ser validos antes de proseguir
    if not schedule_params_valid
      scheduling = @case.scheduling
      @schedule = scheduling.schedule unless scheduling.nil?
      @kiosko = @schedule.kiosko_user.kiosko
      flash.now[:error] = t('time_window_not_valid', scope: :errors)
      return render :edit
    end

    # variables
    kiosko_id = kiosko_params[:id]
    schedule_date = schedule_params[:date]
    schedule_start = schedule_params[:start]
    schedule_end = schedule_params[:end]

    # Cambio el agendamiento?
    if @case.schedule_changed? schedule_date, schedule_start, schedule_end

      # Se intenta obtener el analista asignado por cervello
      analyst_id = User.try(:find_by_email, @case.ws_ticket_analyst_email)
                       .try(:read_attribute, :id)

      # Se intenta obtener una nueva agenda
      new_schedule = Schedule.select_for_new_case(kiosko_id, analyst_id,
                                                             schedule_date,
                                                             schedule_start,
                                                             schedule_end)

      # Agenda disponible?
      if new_schedule
        case_updated = @case.update_with_scheduling(case_params, new_schedule)
      else
        err = t('time_window_taken', scope: :errors)
        flash.now[:error] = err
        case_updated = false
      end
    else
      case_updated = @case.update(case_params)
    end

    if case_updated
      # redirect_to @case
      @case.send_reconfirmation
      SyncSchedulingWorker.perform_async(@case.id)
      render :confirmation
    else
      scheduling = @case.scheduling
      @schedule = scheduling.schedule unless scheduling.nil?
      @kiosko = @schedule.kiosko_user.kiosko
      render :edit
    end
  end

  # DELETE /cases/1
  def destroy
    if @case.destroy
      redirect_to cases_url
    else
      render :index
    end
  end

  # GET /cases/search
  def search
    @cases = []
    @case = Case.new

    # Is search being performed?
    normalized_params = params[:case].nil? ? Hash.new : case_params
    normalized_params = normalized_params.delete_if {|k,v| v.blank?}

    if not (normalized_params == Hash.new)
      @page = params[:page]
      @cases = Case.where(normalized_params).paginate(page: params[:page],
                                                      per_page: 10)
      @case = Case.new(normalized_params)
      @search_performed = true
    end
  end

  # GET /cases/new_reschedule
  def new_reschedule

    if params[:case].nil?
      @case = Case.new
    else
      @case = Case.new(case_params)
    end
  end

  # POST /cases/reschedule
  def reschedule
    @case = Case.where(case_params).first

    # Si el caso no existe, se pasa el control a la accion de reagendamiento
    if @case.nil?
      flash.now[:error] = t('case_not_found', scope: :errors)
      new_reschedule() && render(:new_reschedule)

    # Si el caso existe
    else

      # Numero de agendamientos que ha tenido el ticket
      num_schedulings = @case.schedulings.size

      # Caso cerrado?
      if @case.state.terminal
        flash.now[:error] = t('case_closed', scope: :errors)
        new_reschedule() && render(:new_reschedule)

      # Condicion de maximo de reagendamientos = 3
      elsif num_schedulings >= 3
        flash.now[:error] = t('max_schedulings_reached', scope: :errors)
        new_reschedule() && render(:new_reschedule)
      else
        # se pasa el control a la accion de edicion
        flash.now[:notice] = t('case_found', scope: :errors)
        @lock_form = true
        edit() && render(:edit)
      end
    end
  end

  # GET /cases/1/change_state
  def change_state
  end

  # POST /cases/1/add_state
  def add_state
    if @case.update(case_params)
      SyncStatusWorker.perform_async(@case.id, current_user.to_s)
      redirect_to @case
    else
      render :change_state
    end
  end

  # GET /cases/1/edit_tech
  def edit_tech
    @schedule = @case.schedule
    kiosko_id = @case.kiosko.id

    kiosko_user_ids = KioskoUser
                        .where(:kiosko_id => kiosko_id)
                        .where(:active => true)
                        .pluck(:id)

    # Se traen los schedules disponibles
    @available_schedules = Schedule
                          .where(:kiosko_user_id => kiosko_user_ids)
                          .where(:date => @schedule.date)
                          .where(:start => @schedule.start)
                          .where(:end => @schedule.end)
                          .where(:taken => 0) |
                          Schedule.where(id: @schedule.id)
  end

  # POST /cases/1/change_tech
  def change_tech
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_case
      @case = Case.find(params[:id])
      authorize @case
    end

    # Authorization for class.
    def authorize_cases
      authorize Case
    end

    # Only allow a trusted parameter "white list" through.
    def case_params
      params.require(:case).permit(:ticket, :bp, :email, :state_id)
    end

    def schedule_params
      _params = params.require(:schedule).permit(:datetime)

      datetime = _params[:datetime].split(' ')
      _params[:date] = datetime[0]
      _params[:start] = datetime[1].split('-')[0]
      _params[:end] = datetime[1].split('-')[1]
      _params
    end

    def schedule_params_valid
      def is_valid_date date
        d = date.split('-')
        if d.length == 3
          year = d[0].to_i
          month = d[1].to_i
          day = d[2].to_i
          if (year > 2014) && (month.between?(1, 12)) && (day.between?(1,31))
            return true
          end
        end

        return false
      end

      def is_valid_time time
        t = time.split(':')
        if t.length == 3
          hours = t[0].to_i
          minutes = t[1].to_i
          seconds = t[2].to_i
          if (hours.between?(0, 23) && minutes.between?(0, 59) && seconds == 0)
            return true
          end
        end

        return false
      end

      datetime = params[:schedule][:datetime]
      if datetime.split(' ').length == 2
        date = datetime.split(' ')[0]
        tw = datetime.split(' ')[1]
        if tw.split('-').length == 2
          start_time = tw.split('-')[0]
          end_time = tw.split('-')[1]

          if is_valid_date(date) && is_valid_time(start_time) && is_valid_time(start_time)
            return true
          end
        end
      end

      return false
    end

    def kiosko_params
      params.require(:kiosko).permit(:id)
    end
end
