class ObservationsController < ApplicationController
  before_action :set_observation, only: [:show, :edit, :update, :destroy]
  before_action :set_case#, only: [:new, :edit, :create, :update]
  before_action :authorize_observations, only: [:new, :create, :index]

  # GET /observations
  def index
    @page = params[:page]

    observations_filtered = params[:q].present? ? @case.observations.by_user_name(params[:q]) : @case.observations

    @observations = observations_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(Observation).to_csv?
          send_data Observation.to_csv, filename: "Observations-#{Time.now.to_s(:number)}.csv"
        else
          flash[:error] = t('not_authorized', scope: :pundit)
          redirect_to case_observations_path(@case)
        end
      }
    end
  end

  # GET /observations/1
  def show
  end

  # GET /observations/new
  def new
    @observation = @case.observations.build
  end

  # GET /observations/1/edit
  def edit
  end

  # POST /observations
  def create
    @observation = @case.observations.build(observation_params)
    @observation.user = current_user

    if @observation.save
      SyncObservationWorker.perform_async(@observation.id)
      redirect_to @case, notice: t('success_on_model_action_fem',
                          scope: :crud_views,
                          resource: t('one', scope: [:activerecord, :models, :observation]),
                          action: t('participle_fem', scope: [:actions, :create]))
    else
      render :new
    end
  end

  # PATCH/PUT /observations/1
  def update
    if @observation.update(observation_params)
      redirect_to [@case, @observation], notice: t('success_on_model_action_fem',
                                          scope: :crud_views,
                                          resource: t('one', scope: [:activerecord, :models, :observation]),
                                          action: t('participle_fem', scope: [:actions, :update]))
    else
      render :edit
    end
  end

  # DELETE /observations/1
  def destroy
    if @observation.destroy
      redirect_to observations_url, notice: t('success_on_model_action_fem',
                                      scope: :crud_views,
                                      resource: t('one', scope: [:activerecord, :models, :observation]),
                                      action: t('participle_fem', scope: [:actions, :delete]))
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_observation
      @observation = Observation.find(params[:id])
      authorize @observation
    end

    # Set case
    def set_case
      @case = Case.find(params[:case_id])
    end

    # Authorization for class.
    def authorize_observations
      authorize Observation
    end

    # Only allow a trusted parameter "white list" through.
    def observation_params
      params.require(:observation).permit(:observation, :submit)
    end
end
