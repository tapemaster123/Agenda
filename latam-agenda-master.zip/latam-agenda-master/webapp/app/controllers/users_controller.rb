class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy, :schedulings]
  before_action :authorize_users, only: [:new, :create, :index]

  # GET /users
  def index
    @page = params[:page]

    users_filtered = params[:q].present? ? policy_scope(User.includes(:kioskos, :country)).by_name(params[:q]) : policy_scope(User.includes(:kioskos, :country)).all
    # @users = users_filtered.paginate page: params[:page], per_page: 10
    @users = users_filtered.sort_by { |user| user.tech? ? "#{user.country.name}_#{user.role}_#{user.kioskos.join(' - ')}" : "#{user.country.name}_#{user.role}" }

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(User).to_csv?
          send_data User.to_csv, filename: "Users-#{Time.now.to_s(:number)}.csv"
        else
          flash[:error] = t('not_authorized', scope: :pundit)
          redirect_to case_observations_path(@case)
        end
      }
    end
  end

  # GET /users/1/schedulings
  def schedulings
    @schedulings = @user.schedulings
  end

  # GET /users/1
  def show
  end

  # GET /users/new
  def new
    @user = User.new
    @user.country_id = current_user.country_id unless current_user.system_admin?
  end

  # GET /users/1/edit
  def edit
  end

  # POST /users
  def create
    @user = User.new(user_params)
    @user.country_id = current_user.country_id unless current_user.system_admin?
    if @user.save
      redirect_to @user, notice: t('success_on_model_action',
                            scope: :crud_views,
                            resource: t('one', scope: [:activerecord, :models, :user]),
                            action: t('participle', scope: [:actions, :create]))
    else
      render :new
    end
  end

  # PATCH/PUT /users/1
  def update
    if not needs_update_password? @user, params
      params[:user].delete :current_password
      params[:user].delete :password
      params[:user].delete :password_confirmation
    end

    if @user.update(user_params)
      redirect_to @user, notice: t('success_on_model_action',
                            scope: :crud_views,
                            resource: t('one', scope: [:activerecord, :models, :user]),
                            action: t('participle', scope: [:actions, :update]))
    else
      render :edit
    end
  end

  # DELETE /users/1
  def destroy
    if @user.destroy
      redirect_to users_url, notice: t('success_on_model_action',
                              scope: :crud_views,
                              resource: t('one', scope: [:activerecord, :models, :user]),
                              action: t('participle', scope: [:actions, :dete]))
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_user
      @user = User.find(params[:id])
      authorize @user
    end

    # Authorization for class.
    def authorize_users
      authorize User
    end

    # Check if passwords needs to be updated
    def needs_update_password? user, params
      user.email != params[:user][:email] ||
        params[:user][:password].present? ||
        params[:user][:password_confirmation].present?
    end

    # Only allow a trusted parameter "white list" through.
    def user_params
      if current_user.system_admin?
        params.require(:user).permit(:firstname, :lastname, :email, :bp, :enabled, :role, :password, :password_confirmation, :country_id)
      else
        params.require(:user).permit(:firstname, :lastname, :email, :bp, :enabled, :role, :password, :password_confirmation)
      end
    end
end
