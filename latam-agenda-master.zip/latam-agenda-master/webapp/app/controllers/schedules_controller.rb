class SchedulesController < ApplicationController
  before_action :set_schedule, only: [:show, :edit, :update, :destroy]
  before_action :set_countries, only: [:new, :new_offer, :edit, :create, :create_offer, :update]
  before_action :authorize_schedules, only: [:new, :create, :index, :resume, :detail]
  skip_before_filter :authenticate_user!, only: [:resume, :detail]

  # GET /schedules
  def index
    @page = params[:page]

    schedules_filtered = params[:q].present? ? Schedule.by_kiosko_user_name(params[:q]) : Schedule.all

    @schedules = schedules_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(Schedule).to_csv?
          send_data Schedule.to_csv, filename: "Schedules-#{Time.now.to_s(:number)}.csv"
        else
          flash[:error] = t('not_authorized', scope: :pundit)
          redirect_to case_observations_path(@case)
        end
      }
    end
  end

  # GET /schedules/1
  def show
  end

  # GET /schedules/resume
  def resume
    kiosko_id = params[:kiosko_id]

    # Relaciones kiosko-tecnico para el kiosko seleccionado
    kiosko_user_ids = KioskoUser
                        .where(kiosko_id: kiosko_id)
                        .where(active: true)
                        .pluck(:id)

    # Se traen todas las agendas de 'kiosko_user_ids' para el mes actual y
    # el proximo mes
    # Luego, para cada día, se obtiene el total disponible y el total agendado
    schedules = Schedule
      .where(kiosko_user_id: kiosko_user_ids)
      .where("date >= ?", Date.today)
      .where("date < ?", Date.today.at_beginning_of_month.next_month.next_month)
      .select('date, count(*) as num_available, sum(taken) as num_taken')
      .group('date')

    render json: {
      schedules: schedules
    }, status: 200
  end

  # GET /schedules/detail
  def detail
    kiosko_id = params[:kiosko_id]
    date = params[:date]

    kiosko_user_ids = KioskoUser
                        .where(kiosko_id: kiosko_id)
                        .pluck(:id)
    schedules = Schedule
      .where(kiosko_user_id: kiosko_user_ids)
      .where(date: date)
      .select('date, start, "end", count(*) as num_available, sum(taken) as num_taken')
      .group(['date', 'start', 'end'])
      .order('start asc')

    render json: {
      schedules: schedules
    }, status: 200
  end

  # GET /schedules/new_offer
  def new_offer
    @schedule = Schedule.new
  end

  # GET /schedules/view_offer
  def view_offer
  end

  # POST /schedules/create_offer
  def create_offer
    offer_result = Schedule.create_offer(schedule_params)
    if offer_result[:transaction_ok]
      redirect_to schedules_path, notice: t('success_on_model_action_fem',
                                    scope: :crud_views,
                                    resource: t('offer', scope: [:activerecord, :models, :schedule]),
                                    action: t('participle_fem', scope: [:actions, :create]))
    else
      @schedule = offer_result[:schedule]
      render :new_offer
    end
  end

  # GET /schedules/new
  def new
    @schedule = Schedule.new
  end

  # GET /schedules/1/edit
  def edit
  end

  # POST /schedules
  def create
    @schedule = Schedule.new(schedule_params)

    if @schedule.save
      redirect_to @schedule, notice: t('success_on_model_action_fem',
                              scope: :crud_views,
                              resource: t('one', scope: [:activerecord, :models, :schedule]),
                              action: t('participle_fem', scope: [:actions, :create]))
    else
      render :new
    end
  end

  # PATCH/PUT /schedules/1
  def update
    if @schedule.update(schedule_params)
      redirect_to @schedule, notice: t('success_on_model_action_fem',
                              scope: :crud_views,
                              resource: t('one', scope: [:activerecord, :models, :schedule]),
                              action: t('participle_fem', scope: [:actions, :update]))
    else
      render :edit
    end
  end

  # DELETE /schedules/1
  def destroy
    if @schedule.destroy
      redirect_to schedules_url, notice: t('success_on_model_action_fem',
                                  scope: :crud_views,
                                  resource: t('one', scope: [:activerecord, :models, :schedule]),
                                  action: t('participle_fem', scope: [:actions, :delete]))
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_schedule
      @schedule = Schedule.find(params[:id])
      authorize @schedule
    end

    # Set list of countries
    def set_countries
      @countries = Country.all
    end

    # Authorization for class.
    def authorize_schedules
      authorize Schedule
    end

    # Only allow a trusted parameter "white list" through.
    def schedule_params
      params.require(:schedule).permit(:taken, :kiosko, :kiosko_user_id, :date, :daterange, :start, :end, :slot_size, :with_lunchtime, :start_lunch, :end_lunch, week_days: [], users: [])
    end
end
