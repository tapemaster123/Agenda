class RemindersController < ApplicationController
  before_action :set_reminder, only: [:show, :edit, :update, :destroy]
  #before_action :authorize_reminders, only: [:new, :create, :index]

  # GET /reminders
  def index
    @page = params[:page]

    reminders_filtered = params[:q].present? ? Reminder.where(ticket: params[:q]) : Reminder.all

    @reminders = reminders_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        send_data Reminder.to_csv, filename: "Reminders-#{Time.now.to_s(:number)}.csv"
      }
    end
  end

  # GET /reminders/1
  def show
  end

  # GET /reminders/new
  def new
    @reminder = Reminder.new
  end

  # GET /reminders/1/edit
  def edit
  end

  # POST /reminders
  def create
    @reminder = Reminder.find_by_ticket(reminder_params[:ticket])
    saved = false

    if @reminder.nil?
      @reminder = Reminder.new(reminder_params)
      saved = @reminder.save
    else
      @reminder.times_sent += 1
      saved = @reminder.update(reminder_params)
    end

    if saved
      @reminder.send_link(reminder_params)
      redirect_to @reminder, notice: t('link_sent')
    else
      render :new
    end
  end

  # PATCH/PUT /reminders/1
  def update
    if @reminder.update(reminder_params)
      if extra_params[:close_in_cervello].present? and not @reminder.active?
        # logger.info 'Cerrando ticket en cervello'
        @reminder.cancel_remote_ticket(@reminder.ticket)
      end

      redirect_to @reminder
    else
      render :edit
    end
  end

  # DELETE /reminders/1
  def destroy
    if @reminder.destroy
      redirect_to reminders_url
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_reminder
      @reminder = Reminder.find(params[:id])
      #authorize @reminder
    end

    # Authorization for class.
    def authorize_reminders
      authorize Reminder
    end

    # Only allow a trusted parameter "white list" through.
    def reminder_params
      params.require(:reminder).permit(:ticket, :bp, :email, :times_sent, :active)
    end

    def extra_params
      params.permit(:close_in_cervello)
    end
end
