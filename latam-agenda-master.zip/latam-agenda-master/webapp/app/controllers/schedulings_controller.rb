class SchedulingsController < ApplicationController
  before_action :set_scheduling, only: [:show, :edit, :update, :destroy]
  #before_action :authorize_schedulings, only: [:new, :create, :index]

  # GET /schedulings
  def index
    @page = params[:page]

    schedulings_filtered = params[:q].present? ? Scheduling.by_name(params[:q]) : Scheduling.all

    @schedulings = schedulings_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      #format.csv { send_data Scheduling.to_csv, filename: "Schedulings-#{Time.now.to_s(:number)}.csv" }
    end
  end

  # GET /schedulings/detail.json
  def detail
    user_id = params[:user_id]
    date_ini = Time.now.utc.to_date
    date_end = Time.now.utc.to_date + 8.week

    user = User.find(user_id)
    schedules_ids = user.schedules.daterange(date_ini, date_end).pluck(:id)
    @schedulings = Scheduling
      .where(schedule_id: schedules_ids)
      .actives

    # Display the data collected according to a format
    respond_to do |format|
      format.json
    end
  end

  # GET /schedulings/1
  def show
  end

  # GET /schedulings/new
  def new
    @scheduling = Scheduling.new
  end

  # GET /schedulings/1/edit
  def edit
  end

  # POST /schedulings
  def create
    @scheduling = Scheduling.new(scheduling_params)

    if @scheduling.save
      redirect_to @scheduling
    else
      render :new
    end
  end

  # PATCH/PUT /schedulings/1
  def update
    if @scheduling.update(scheduling_params)
      redirect_to @scheduling
    else
      render :edit
    end
  end

  # DELETE /schedulings/1
  def destroy
    if @scheduling.destroy
      redirect_to schedulings_url
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_scheduling
      @scheduling = Scheduling.find(params[:id])
      #authorize @scheduling
    end

    # Authorization for class.
    def authorize_schedulings
      authorize Scheduling
    end

    # Only allow a trusted parameter "white list" through.
    def scheduling_params
      params.require(:scheduling).permit(:schedule_id, :case_id)
    end
end
