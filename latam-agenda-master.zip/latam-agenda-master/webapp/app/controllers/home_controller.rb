class HomeController < ApplicationController
  def index
    if current_user.assistant?
        redirect_to new_link_cases_path
    end
  end
end
