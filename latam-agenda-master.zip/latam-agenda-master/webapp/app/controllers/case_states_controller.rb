class CaseStatesController < ApplicationController
  before_action :set_case_state, only: [:show, :edit, :update, :destroy]
  #before_action :authorize_case_states, only: [:new, :create, :index]

  # GET /case_states
  def index
    @page = params[:page]

    case_states_filtered = params[:q].present? ? CaseState.by_name(params[:q]) : CaseState.all

    @case_states = case_states_filtered.paginate page: params[:page], per_page: 10
    
    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      #format.csv { send_data CaseState.to_csv, filename: "CaseStates-#{Time.now.to_s(:number)}.csv" }
    end
  end

  # GET /case_states/1
  def show
  end

  # GET /case_states/new
  def new
    @case_state = CaseState.new
  end

  # GET /case_states/1/edit
  def edit
  end

  # POST /case_states
  def create
    @case_state = CaseState.new(case_state_params)

    if @case_state.save
      redirect_to @case_state
    else
      render :new
    end
  end

  # PATCH/PUT /case_states/1
  def update
    if @case_state.update(case_state_params)
      redirect_to @case_state
    else
      render :edit
    end
  end

  # DELETE /case_states/1
  def destroy
    if @case_state.destroy
      redirect_to case_states_url
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_case_state
      @case_state = CaseState.find(params[:id])
      #authorize @case_state
    end

    # Authorization for class.
    def authorize_case_states
      authorize CaseState
    end

    # Only allow a trusted parameter "white list" through.
    def case_state_params
      params.require(:case_state).permit(:state_id, :case_id)
    end
end
