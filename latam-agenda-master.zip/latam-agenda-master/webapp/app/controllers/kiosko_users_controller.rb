class KioskoUsersController < ApplicationController
  before_action :set_kiosko_user, only: [:show, :edit, :update, :destroy]
  before_action :authorize_kiosko_users, only: [:new, :create, :index]

  # GET /kiosko_users
  def index
    @page = params[:page]

    kiosko_users_filtered = params[:q].present? ? policy_scope(KioskoUser).by_user_name(params[:q]) : policy_scope(KioskoUser).all
    kiosko_users_filtered = kiosko_users_filtered
                            .includes(:kiosko, :user)
                            .order('kioskos.name ASC', 'users.firstname ASC')

    @kiosko_users = kiosko_users_filtered.paginate page: params[:page], per_page: 10

    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      format.csv {
        if policy(KioskoUser).to_csv?
          end_data KioskoUser.to_csv, filename: "KioskoUsers-#{Time.now.to_s(:number)}.csv"
        else
          flash[:error] = t('not_authorized', scope: :pundit)
          redirect_to kiosko_users_path
        end
      }
    end
  end

  # GET /kiosko_users/1
  def show
  end

  # GET /kiosko_users/new
  def new
    @kiosko_user = KioskoUser.new
  end

  # GET /kiosko_users/1/edit
  def edit
  end

  # POST /kiosko_users
  def create
    @kiosko_user = KioskoUser.new(kiosko_user_params)

    if @kiosko_user.save

      redirect_to @kiosko_user, notice: t('create', scope: [:actions, :associate_user_kiosko])
    else
      render :new
    end
  end

  # PATCH/PUT /kiosko_users/1
  def update
    if @kiosko_user.update(kiosko_user_params)
      redirect_to @kiosko_user, notice: t('update', scope: [:actions, :associate_user_kiosko])
    else
      render :edit
    end
  end

  # DELETE /kiosko_users/1
  def destroy
    if @kiosko_user.destroy
      redirect_to kiosko_users_url, notice: t('destroy', scope: [:actions, :associate_user_kiosko])
    else
      render :index
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_kiosko_user
      @kiosko_user = KioskoUser.find(params[:id])
      authorize @kiosko_user
    end

    # Authorization for class.
    def authorize_kiosko_users
      authorize KioskoUser
    end

    # Only allow a trusted parameter "white list" through.
    def kiosko_user_params
      params.require(:kiosko_user).permit(:active, :kiosko_id, :user_id)
    end
end
