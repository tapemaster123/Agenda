class CountriesController < ApplicationController
  before_action :set_country, only: [:show, :edit, :update, :destroy, :kioskos]
  before_action :authorize_countries, only: [:new, :create, :index]

  # GET /countries/1/kioskos.json
  def kioskos
    # Solo kioskos activos
    @kioskos = @country.kioskos.enabled
    respond_to do |format|
      format.json
    end
  end

  # GET /countries
  def index
    @page = params[:page]

    countries_filtered = params[:q].present? ? Country.by_name(params[:q]) : Country.all

    @countries = countries_filtered.paginate page: params[:page], per_page: 10
    
    # Display the data collected according to a format
    respond_to do |format|
      format.html
      format.json
      #format.csv { send_data Country.to_csv, filename: "Countries-#{Time.now.to_s(:number)}.csv" }
    end
  end

  # GET /countries/1
  def show
  end

  # GET /countries/new
  def new
    @country = Country.new
  end

  # GET /countries/1/edit
  def edit
  end

  # POST /countries
  def create
    @country = Country.new(country_params)

    if @country.save
      redirect_to @country, notice: t('success_on_model_action',
                              scope: :crud_views,
                              resource: t('one', scope: [:activerecord, :models, :country]),
                              action: t('participle', scope: [:actions, :create]))
    else
      render :new
    end
  end

  # PATCH/PUT /countries/1
  def update
    if @country.update(country_params)
      redirect_to @country, notice: t('success_on_model_action',
                              scope: :crud_views,
                              resource: t('one', scope: [:activerecord, :models, :country]),
                              action: t('participle', scope: [:actions, :update]))
    else
      render :edit
    end
  end

  # DELETE /countries/1
  def destroy
    if @country.destroy
      redirect_to countries_url, notice: t('success_on_model_action',
                                  scope: :crud_views,
                                  resource: t('one', scope: [:activerecord, :models, :country]),
                                  action: t('participle', scope: [:actions, :delete]))
    else
      render :show
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_country
      @country = Country.find(params[:id])
      authorize @country
    end

    # Authorization for class.
    def authorize_countries
      authorize Country
    end

    # Only allow a trusted parameter "white list" through.
    def country_params
      params.require(:country).permit(:name, :alpha_code)
    end
end
