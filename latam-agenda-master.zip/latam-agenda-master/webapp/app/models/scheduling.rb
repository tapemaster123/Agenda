#encoding: utf-8
class Scheduling < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id schedule case active created_at}

  # Relations
  belongs_to :schedule
  belongs_to :case

  # Callbacks
  # Put here custom callback methods for Scheduling

  # Validations
  # validates :schedule, <validations>
  # validates :case, <validations>

  # Scopes (used for search form)
  scope :actives, -> { where active: 1 }
  scope :by_date, ->(date) { where created_at: date}

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.schedule} - #{self.case}"  # editable
  end
  
end
