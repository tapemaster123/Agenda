#encoding: utf-8
class Case < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id ticket bp email kiosko tech created_at}

  SAVON_CONFIG = {
    wsdl: 'http://latam-cervellowebservices.accenture.com/webservicev3/Integracao.asmx?WSDL',
    env_namespace: :soapenv,
    namespace_identifier: :tem
  }

  # Relations
  has_one :scheduling, -> { where(active: 1) }
  has_one :schedule, through: :scheduling
  has_one :kiosko_user, through: :schedule
  has_one :kiosko, through: :kiosko_user
  has_one :country, through: :kiosko
  has_one :tech, through: :kiosko_user, source: :user
  has_one :case_state, -> { order 'case_states.created_at DESC' }, :class_name => "CaseState"
  has_one :status, through: :case_state, :class_name => "State", :source => "state"

  has_many :schedulings
  has_many :schedules, through: :schedulings
  has_many :case_states
  has_many :states, through: :case_states
  has_many :observations

  # Callbacks
  before_create :set_default_state
  before_save :downcase_email

  # Validations
  # validates :ticket, <validations>
  validates :ticket,
    presence: true,
    uniqueness: true

  validates :bp,
    presence: true

  validates :email,
    presence: true,
    format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i}


  # Scopes (used for search form)
  scope :by_ticket, ->(ticket) { where('ticket ILIKE ?', "%#{ticket}%") }

  # Static methods
  def self.send_reminders
    taken_schedules = Schedule.where("date = ?", Date.today + 1).where(taken: 1)
    taken_schedules.each do |schedule|
      schedule.case.send_reminder
    end
  end

  def self.to_csv
    attributes = %w{id ticket bp email country kiosko creation_date creation_time booked_date booked_start_time booked_end_time current_status}

    CSV.generate(headers: true) do |csv|
      csv << attributes

      all.each do |_case|
        csv << attributes.map{ |attr| _case.send(attr) }
      end
    end
  end

  # Virtual attributes
  # def schedule_id
  #   self.schedule.id
  # end

  # def schedule_id=(new_schedule_id)
  # end

  # USADOS en CSV
    def creation_date
      self.created_at.strftime('%d/%m/%Y')
    end

    def creation_time
      self.created_at.strftime('%H:%M')
    end

    def booked_date
      self.get_booked_date
    end

    def booked_start_time
      self.get_booked_start
    end

    def booked_end_time
      self.get_booked_end
    end

    def current_status
      # self.states.order('created_at DESC').first
      self.status
    end
  # /USADOS en CSV

  def state_id
    state.id
  end

  def state_id=(new_state_id)
    new_state_obj = State.find(new_state_id)
    self.states.push(new_state_obj)
  end

  def state
    get_current_state
  end

  def state=(new_state)
    if new_state.instance_of? State
      self.states.push(new_state)
    end
  end

  # Instance methods

  # Override to_s method
  def to_s
    ticket  # editable
  end

  def downcase_email
    self.email.downcase!
  end

  def fetch_case_person_information
    # Sync only when app is in production mode
    return true unless Rails.env.production?

    client = Savon.client(
      wsdl: Parameter.find_by_key('WS_WSDL').value,
      env_namespace: Parameter.find_by_key('WS_ENV_NAMESPACE').value,
      namespace_identifier: Parameter.find_by_key('WS_NAMESPACE_IDENTIFIER').value
    )

    # Buscar la informacion de una persona y caso al mismo tiempo
    response = client.call(
      :lookup_person_case_information,
      message: {
        'InputObj' => {
          'IncidentNumber' => self.ticket,
          'EmailAdress' => self.email
        }
      }
    )

    body = response.body
    remote_information = body.try(:[], :lookup_person_case_information_response)
                             .try(:[], :lookup_person_case_information_result)
    if remote_information.nil?
      errors.add(:base, I18n.t('not_response', scope: :cervello))
      return false
    end

    if remote_information[:result_code] != "0" || remote_information[:bp_usuario].nil?
      errors.add(:ticket, I18n.t('ticket_not_found', scope: :cervello))
      return false
    end

    self.ws_user_bp = remote_information[:bp_usuario]
    self.ws_user_fullname = remote_information[:nombre_usuario]
    self.ws_user_type = remote_information[:tipo_usuario]
    self.ws_user_country = remote_information[:pais]
    self.ws_user_site = remote_information[:site]
    self.ws_user_phone = remote_information[:telefono]
    self.ws_user_annex = remote_information[:anexo]
    self.ws_ticket_description = remote_information[:descripcion]
    self.ws_ticket_detail = remote_information[:detalle]
    self.ws_ticket_type = remote_information[:tipo_ticket]
    self.ws_ticket_aperture_date = remote_information[:fecha_apertura]
    self.ws_ticket_status = remote_information[:status]
    self.ws_ticket_resolutor_group = remote_information[:grupo_resolutor]
    self.ws_ticket_analyst = remote_information[:analista]
    self.ws_ticket_analyst_email = remote_information[:analyst_email]
    self.ws_ticket_analyst_email.downcase! unless self.ws_ticket_analyst_email.nil?

    return true

  rescue
    errors.add(:base, I18n.t('not_response', scope: :cervello))
    return false
  end

  def set_default_state
    default_state = State.find_by_name('Abierto')
    self.states.push(default_state) unless default_state.nil?
  end

  def get_current_state
    self.states.order('created_at DESC').first
  end

  def get_kiosco
    return nil if self.scheduling.nil?
    return self.scheduling.schedule.kiosko_user.kiosko
  end

  def get_booked_date
    return nil if self.scheduling.nil?
    return self.scheduling.schedule.date
  end

  def get_booked_time_window
    return nil if self.schedule.nil?
    return self.schedule.time_window_to_s
  end

  def get_booked_start
    return nil if self.scheduling.nil?
    return self.scheduling.schedule.start.strftime('%H:%M')
  end

  def get_booked_end
    return nil if self.scheduling.nil?
    return self.scheduling.schedule.end.strftime('%H:%M')
  end

  def get_assigned_employee
    return nil if self.scheduling.nil?
    return self.scheduling.schedule.kiosko_user.user
  end

  def case_code
    "LA#{id.to_s.rjust(8, '0')}"
  end

  def send_link_for_create (params)
    CaseMailer.delay.link_email(params)
  end

  def send_confirmation
    CaseMailer.delay.case_confirmation(self.id)
  end

  def send_reconfirmation
    CaseMailer.delay.case_reconfirmation(self.id)
  end

  def send_reminder
    CaseMailer.delay.case_reminder(self.id)
  end

  def schedule_changed? schedule_date, schedule_start, schedule_end
    return false if self.scheduling.nil?

    schedule = self.scheduling.schedule
    return !((schedule_date == schedule.date.strftime('%Y-%m-%d')) &&
           (schedule_start == schedule.start.strftime('%H:%M:%S')) &&
           (schedule_end == schedule.end.strftime('%H:%M:%S')))
  end

  def save_with_scheduling (schedule)
    transaction_ok = true

    # Transaccion
    case_saved = false
    scheduling_saved = false
    schedule_saved = false
    ActiveRecord::Base.transaction do

      # Se crea el caso
      case_saved = self.save

      # Se agenda
      @scheduling = Scheduling.new({
        :schedule => schedule,
        :case => self,
        :active => true
      })
      scheduling_saved = @scheduling.save

      # Se actualiza el schedule
      schedule_saved = schedule.update_attribute(:taken, 1)
      schedule_saved = schedule_saved && schedule.update_attribute(:taken_sometime, 1)
      if !(case_saved && scheduling_saved && schedule_saved)
        transaction_ok = false
        raise ActiveRecord::Rollback
      end
    end

    return transaction_ok
  end

  def update_with_scheduling (case_params, schedule)
    transaction_ok = true

    # Transaccion
    case_updated = false
    old_scheduling_saved = true
    old_schedule_saved = true
    scheduling_saved = false
    schedule_saved = false
    ActiveRecord::Base.transaction do

      # Se desapropia el agendamiento existente
      old_scheduling = self.scheduling
      if old_scheduling
        old_scheduling_saved = old_scheduling.update_attribute(:active, false)
        old_schedule_saved = old_scheduling.schedule.update_attribute(:taken, 0)
      end

      # Se actualiza el caso
      case_updated = self.update(case_params)

      # Se agenda
      @scheduling = Scheduling.new({
        :schedule => schedule,
        :case => self,
        :active => true
      })
      scheduling_saved = @scheduling.save

      # Se actualiza el schedule
      schedule_saved = schedule.update_attribute(:taken, 1)

      if !(case_updated && scheduling_saved && schedule_saved &&
                                               old_scheduling_saved &&
                                               old_schedule_saved)
        transaction_ok = false
        raise ActiveRecord::Rollback
      end
    end

    return transaction_ok
  end
end
