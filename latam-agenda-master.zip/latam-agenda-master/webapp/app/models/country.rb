#encoding: utf-8
class Country < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id name alpha_code}

  # Relations
  has_many :kioskos, dependent: :restrict_with_error

  # Callbacks
  # Put here custom callback methods for Country

  # Validations
  # validates :name, <validations>
  # validates :alpha_code, <validations>
  
  # Scopes (used for search form)
  # Put here custom queries for Country
  scope :by_name, ->(name) { where("name ILIKE ?", "%#{name}%") } # Scope for search

  # Instance methods

  # Override to_s method
  def to_s
    name  # editable
  end
  
end
