#encoding: utf-8
class Parameter < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id key value created_at updated_at}

  # Relations

  # Callbacks
  # Put here custom callback methods for Parameter

  # Validations
  # validates :key, <validations>
  # validates :value, <validations>
  
  # Scopes (used for search form)
  scope :by_key, ->(key) { where("key ILIKE ?", "%#{key}%") }

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.key}"  # editable
  end
  
end
