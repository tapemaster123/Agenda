#encoding: utf-8
class User < ActiveRecord::Base
  include Exportable

  # Include default devise modules. Others available are:
  # :registerable, :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable,
         :recoverable, :rememberable, :trackable, :validatable

  # Constants
  ROLES = [
    { id: 0, name: 'system_admin' },
    { id: 10, name: 'system_manager' },
    { id: 20, name: 'tech' },
    { id: 30, name: 'assistant' },
  ]
  ATTRS = %w{id name email bp enabled role_name created_at updated_at} # Attributes for CSV export

  # Relations
  belongs_to :country
  has_many :kiosko_users
  has_many :kioskos, -> { order 'kioskos.name' }, through: :kiosko_users
  has_many :schedules, through: :kiosko_users
  has_many :schedulings, through: :schedules
  has_many :observations

  # Callbacks
  # Put here custom callback methods for User

  # Validations
  # validates :firstname, <validations>
  # validates :lastname, <validations>
  # validates :email, <validations>
  # validates :bp, <validations>
  # validates :enabled, <validations>
  validates :role,
    presence: true

  # Scopes (used for search form)
  # Put here custom queries for User
  default_scope { order lastname: :asc }
  scope :by_name, ->(name) { where("firstname ILIKE ? OR lastname ILIKE ?", "%#{name}%", "%#{name}%") } # Scope for search
  scope :by_role, ->(role) { where role: role }
  scope :enabled, -> { where enabled: true }
  scope :admins, -> { where role: 0 }
  scope :managers, -> { where role: 10 }
  scope :techs, -> { where role: 20 }
  scope :assistants, -> { where role: 30 }
  scope :common_users, -> { where role: 30 }

  # Class methods
  def self.all_for_select
    ROLES.map do |role|
      [role[:name], self.by_role(role[:id]).map { |u| [u.name, u.id] }]
    end
  end

  def self.all_techs_for_select(country_id = nil)
    country_scope = country_id ? Country.where(id: country_id) : Country.all
    country_scope.map do |country|
      [country.name, User.where(country_id: country.id).by_role(20).map { |u| [u.name, u.id] }]
    end
  end

  # Instance methods

  # Override to_s method
  def to_s
    name
  end

  # Human name
  def name
    "#{firstname} #{lastname}"
  end

  # Get role name
  def role_name
    rol = ROLES.find { |r| r[:id] == self.role }
    rol.nil? ? I18n.t('rol_undefined', scope: :crud_views) : I18n.t(rol[:name], scope: :user_roles)
  end

  def system_admin?   ; role == 0       ; end
  def system_manager? ; role == 10      ; end
  def manager?        ; system_manager? ; end
  def tech?           ; role == 20      ; end
  def assistant?      ; role == 30      ; end

  # Get enabled representation
  def enabled_user
    self.enabled ? I18n.t('boolean_true', scope: [:activerecord, :others]) : I18n.t('boolean_false', scope: [:activerecord, :others])
  end
end
