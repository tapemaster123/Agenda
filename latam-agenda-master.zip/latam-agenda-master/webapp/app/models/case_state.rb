#encoding: utf-8
class CaseState < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id state case created_at}

  # Relations
  belongs_to :state
  belongs_to :case

  # Callbacks
  # Put here custom callback methods for CaseState

  # Validations
  # validates :state, <validations>
  # validates :case, <validations>

  # Scopes (used for search form)
  # Put here custom queries for CaseState

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.case} - #{self.state}"  # editable
  end
  
end
