#encoding: utf-8
class Observation < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id observation case user created_at updated_at}

  # Relations
  belongs_to :case
  belongs_to :user

  # Callbacks
  after_create :send_email_to_user

  # Validations
  # validates :observation, <validations>
  # validates :case, <validations>
  # validates :user, <validations>

  # Scopes (used for search form)
  scope :by_user_name, ->(name) { joins(:user).where("users.firstname ILIKE ? OR users.lastname ILIKE ?", "%#{name}%", "%#{name}%") } # Scope for search

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.id}"  # editable
  end

  def send_email_to_user
    if self.submit > 0
      CaseMailer.delay.case_observation(self.case.id, self.id)
    end
  end

end
