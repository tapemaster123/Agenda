#encoding: utf-8
class Kiosko < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id name enabled country created_at updated_at}

  # Relations
  belongs_to :country
  has_many :kiosko_users, :dependent => :restrict_with_error
  has_many :users, through: :kiosko_users

  # Callbacks
  # Put here custom callback methods for Kiosko

  # Validations
  validates :name,
    presence: true,
    uniqueness: { scope: :country }
  # validates :enabled, <validations>
  validates :country,
    presence: true

  # Scopes (used for search form)
  # Put here custom queries for Kiosko
  # default_scope { order name: :asc }
  scope :by_name, ->(name) { where("kioskos.name ILIKE ?", "%#{name}%") } # Scope for search
  scope :enabled, -> { where enabled: true }

  # Class methods
  def self.all_for_select(country_id = nil)
    country_scope = country_id ? Country.where(id: country_id) : Country.all
    country_scope.map do |country|
      [country, country.kioskos.map { |k| [k.name, k.id] }]
    end
  end

  # Instance methods

  # Override to_s method
  def to_s
    name  # editable
  end

  # Get enabled representation
  def enabled_kiosko
    self.enabled ? I18n.t('boolean_true', scope: [:activerecord, :others]) : I18n.t('boolean_false', scope: [:activerecord, :others])
  end

  def get_location
    self.location.present? ? self.location : 'NULL'
  end

  def get_map_url
    self.map_url.present? ? self.map_url : '#'
  end

end
