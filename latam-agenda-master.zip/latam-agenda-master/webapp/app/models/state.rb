#encoding: utf-8
class State < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id name terminal}

  # Relations

  # Callbacks
  # Put here custom callback methods for State

  # Validations
  validates :name,
    presence: true
  # validates :terminal, <validations>

  # Scopes (used for search form)
  # Put here custom queries for State
  scope :by_name, ->(name) { where("name ILIKE ?", "%#{name}%") } # Scope for search

  # Instance methods

  # Override to_s method
  def to_s
    name  # editable
  end

  def fullname
    "#{name} [Cervello -> #{remote_status}]"
  end

  # Check if state is terminal with human representation
  def is_terminal?
    self.terminal ? I18n.t('boolean_true', scope: [:activerecord, :others]) : I18n.t('boolean_false', scope: [:activerecord, :others])
  end

end
