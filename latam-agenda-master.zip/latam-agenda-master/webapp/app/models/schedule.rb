#encoding: utf-8
class Schedule < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id kiosko user date start end taken_schedule created_at updated_at}
  SLOTS = [
    { id: 1, minutes: 15,  x: 15, slot: 'x_minutes' },
    { id: 2, minutes: 20,  x: 20, slot: 'x_minutes' },
    { id: 3, minutes: 30,  x: 30, slot: 'x_minutes' },
    { id: 4, minutes: 60,  x: 1, slot: 'x_hours' },
    { id: 4, minutes: 120, x: 2, slot: 'x_hours' },
    { id: 4, minutes: 180, x: 3, slot: 'x_hours' },
  ]

  # Relations
  belongs_to :kiosko_user
  has_one :user, through: :kiosko_user
  has_one :kiosko, through: :kiosko_user
  has_one :scheduling, -> { where(active: 1) }
  has_one :case, through: :scheduling
  has_many :schedulings
  has_many :cases, through: :schedulings

  # Callbacks
  # Put here custom callback methods for Schedule

  # Validations
  validates :date,
    presence: true
  validates :start,
    presence: true
  validates :end,
    presence: true
  validates :kiosko_user,
    presence: true
  #validates :taken,

  # Custom validators
  validate :start_before_end
  validate :user_available

  # Scopes (used for search form)
  scope :by_kiosko_user_name, ->(name) { joins(:user).joins(:kiosko).where("users.firstname ILIKE ? OR users.lastname ILIKE ?", "%#{name}%", "%#{name}%") } # Scope for search
  scope :by_date, ->(date) { where date: date }
  scope :daterange, ->(date_ini, date_end) { where("date >= ? AND date < ?", date_ini, date_end ) }

  # Static methods
  def self.select_for_new_case (kiosko_id, user_id,
                                           schedule_date,
                                           schedule_start,
                                           schedule_end)

    # Se intenta obtener un schedule asociado al analysta definido en cervello
    kiosko_user_ids = KioskoUser
                       .where(:kiosko_id => kiosko_id)
                       .where(:user_id => user_id)
                       .where(:active => true)
                       .pluck(:id)

    schedule = Schedule
                .where(:kiosko_user_id => kiosko_user_ids)
                .where(:date => schedule_date)
                .where(:start => schedule_start)
                .where(:end => schedule_end)
                .where(:taken => 0)
                .sample

    # unless schedule.nil?
    #   puts "Encontrado schedule para el tech #{schedule.user}"
    # end

    return schedule unless schedule.nil?

    # Se repite el proceso anterior pero ahora se selecciona cualquier tecnico
    # Relaciones kiosko-tecnico para el kiosko seleccionado
    kiosko_user_ids = KioskoUser
                        .where(:kiosko_id => kiosko_id)
                        .where(:active => true)
                        .pluck(:id)

    # Se trae un schedule para crear un agendamiento para un caso
    schedule = Schedule
      .where(:kiosko_user_id => kiosko_user_ids)
      .where(:date => schedule_date)
      .where(:start => schedule_start)
      .where(:end => schedule_end)
      .where(:taken => 0)
      .sample # Obtiene un item al azar del conjunto anterior

    # unless schedule.nil?
    #   puts "Tomado schedule del tech #{schedule.user}"
    # end

    return schedule

  end

  # Elimina de la BD todos los schedules antiguos que fueron creados y
  # nunca se agendaron
  def self.delete_old_and_not_used
    Schedule.where("date < ?", Date.today - 3.day)
            .where(:taken_sometime => 0)
            .delete_all
  end

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.kiosko} - #{self.user}"  # editable
  end

  def datetime
    "#{self.date.strftime('%Y-%m-%d')} #{self.start.strftime('%H:%M')}-#{self.end.strftime('%H:%M')}"
  end

  def case

    # TODO: Hacer el join directo con caso
    scheduling = self.schedulings.where(:active => 1).first
    return scheduling.nil? ? nil : scheduling.case
  end

  def get_scheduling
    self.schedulings.where(:active => 1).first
  end

  def time_window_to_s
    "#{start.strftime('%H:%M:%S')}-#{self.end.strftime('%H:%M:%S')}"
  end

  def get_user
    kiosko_user.user
  end

  def taken_schedule
    self.taken == 0 ? I18n.t('boolean_false', scope: [:activerecord, :others]) : I18n.t('boolean_true', scope: [:activerecord, :others])
  end

  def self.create_offer params
    transaction_ok = true
    last_schedule = Schedule.new

    # Parámetros
    country         = params[:country]
    kiosko          = params[:kiosko]
    users           = params[:users]
    kiosko_usuarios = KioskoUser.where(kiosko_id: kiosko, user_id: users)
    daterange       = params[:daterange] # String "DD/MM/YYYY - DD/MM/YYYY"
    date_ini        = daterange[0..9] # String "DD/MM/YYYY"
    date_end        = daterange[-10..-1] # String "DD/MM/YYYY"
    slot_size       = params[:slot_size].to_i # Number
    time_ini        = params[:start] # String "HH:MM"
    time_end        = params[:end] # String "HH:MM"
    with_lunchtime  = params[:with_lunchtime] # Boolean
    lunch_ini       = params[:start_lunch] # String "HH:MM"
    lunch_end       = params[:end_lunch] # String "HH:MM"
    week_days       = params[:week_days] # Array

    # Variables
    slots = [time_ini]
    time_temp = time_ini.to_time

    # Se guardan los bloques de tiempo en un Array en formato string "HH:MM"
    ((time_end.to_time - time_temp) / 60 / slot_size).to_i.times do
      time_temp = time_temp + slot_size.minutes
      slots << time_temp.to_s(:time)
    end

    # Transacción de creación de agendas
    ActiveRecord::Base.transaction do
      # Para cada día de la semana seleccionado dentro del rango de fechas y cada slot se crea un schedule.
      date_ini.to_date.upto(date_end.to_date) do |date|

        # Se finaliza el ciclo si hay error
        break unless transaction_ok

        # Se chequea que el día de la semana esté incluido entre las elecciones
        next unless ((date.wday - 1) % 7).to_s.in? week_days

        # Para cada slot de tiempo se crea un schedule
        # Excepto los bloques que topan con almuerzo
        slots.each_with_index do |slot, index|

          # Se finaliza el ciclo si hay error
          break unless transaction_ok

          # Siguiente iteración si se trata del último slot
          # O si el slot actual topa con almuerzo
          next if slot == slots.last ||(with_lunchtime && slot >= lunch_ini && slot < lunch_end)

          # Se crea schedule para cada usuario
          kiosko_usuarios.each do |kiosko_usuario|
            current_schedule = Schedule.new({
              :kiosko_user_id => kiosko_usuario.id,
              :date => date,
              :start => slots[index],
              :end => slots[index + 1],
              :taken => false,
              :taken_sometime => false
            })
            unless current_schedule.save
              last_schedule = current_schedule # Se guarda para mostrar mensaje de error
              transaction_ok = false
              break
            end
          end
        end
      end

      # Si hay errores se hace un rollback de la transacción actual
      raise ActiveRecord::Rollback unless transaction_ok

    end # Fin de transacción

    return { schedule: last_schedule, transaction_ok: transaction_ok }
  end

  private
    # Valida que la hora de inicio del rango sea menor que la de termino
    def start_before_end
      if self.start >= self.end
        errors.add(:start, I18n.t('before', scope: [:errors, :messages, :custom], attribute: :end))
      end
    end

    # Valida que el usuario tenga disponibilidad horaria en la fecha y horario seleccionado
    def user_available
      # Se obtienen todos los schedules del usuario ese dia
      schedules = Schedule.where(
                            kiosko_user_id: KioskoUser.where(user_id: self.user.id).pluck(:id),
                            date: self.date)

      # Muy lento en el peor caso
      schedules.each do |schedule|
        unless self.end <= schedule.start || self.start >= schedule.end
          errors.add(:kiosko_user,
            I18n.t('user_not_available', scope: [:errors, :messages, :custom],
              date: I18n.l(self.date, format: :medium),
              start_time: I18n.l(self.start, format: :time),
              end_time: I18n.l(self.end, format: :time),
              user: self.kiosko_user.user.to_s))
          break
        end
      end
    end

end
