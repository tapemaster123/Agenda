#encoding: utf-8
class KioskoUser < ActiveRecord::Base
  include Exportable

  # Constants
  ATTRS = %w{id kiosko user active created_at} # Attributes for CSV export

  # Relations
  has_many :schedules
  has_many :schedulings, through: :schedules
  belongs_to :kiosko
  belongs_to :user

  # Callbacks
  # Put here custom callback methods for KioskoUser

  # Validations
  # validates :active, <validations>
  validates :kiosko,
    presence: true,
    uniqueness: { scope: :user }
  validates :user,
    presence: true
  validate :same_country_policy


  # Scopes (used for search form)
  # Put here custom queries for KioskoUser
  scope :by_user_name, ->(name) { joins(:user).where("users.firstname ILIKE ? OR users.lastname ILIKE ?", "%#{name}%", "%#{name}%") } # Scope for search

  # Instance methods

  # Override to_s method
  def to_s
    "#{self.user} - #{self.kiosko}"  # editable
  end

  # Get active representation
  def active_user_kiosko
    self.active ? I18n.t('boolean_true', scope: [:activerecord, :others]) : I18n.t('boolean_false', scope: [:activerecord, :others])
  end

  def same_country_policy
    unless self.kiosko.country_id == self.user.country_id
      errors.add(:base, I18n.t('user_kiosko_not_same_country', scope: [:errors]))
    end
  end

end
