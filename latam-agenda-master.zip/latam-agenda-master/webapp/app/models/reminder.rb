#encoding: utf-8
class Reminder < ActiveRecord::Base
  include Exportable

  # Constants
  # Put here constants for Reminder

  # Relations

  # Callbacks
  # Put here custom callback methods for Reminder
  before_save :default_values

  # Validations
  # validates :ticket, <validations>
  # validates :bp, <validations>
  # validates :email, <validations>
  # validates :times_sent, <validations>
  # validates :active, <validations>


  # Scopes (used for search form)
  # Put here custom queries for Reminder
  # scope :by_name, ->(name) { where("name ILIKE ?", "%#{name}%") } # Scope for search

  def self.send_all
    reminders = Reminder.where(active: true)
    reminders.each do |reminder|
      reminder.send_email_or_cancel
    end

    true
  end

  def self.to_csv
    # attributes = %w{id ticket bp email times_sent created_at active}

    CSV.generate(headers: true) do |csv|
      csv << ['Id',
              I18n.t('ticket', scope: [:activerecord, :attributes, :reminder]),
              I18n.t('bp', scope: [:activerecord, :attributes, :reminder]),
              I18n.t('email', scope: [:activerecord, :attributes, :reminder]),
              I18n.t('times_sent', scope: [:activerecord, :attributes, :reminder]),
              I18n.t('created_at', scope: [:activerecord, :attributes, :reminder]),
              I18n.t('updated_at', scope: [:activerecord, :others]),
              I18n.t('active', scope: [:activerecord, :attributes, :reminder])]

      all.each do |reminder|
        csv << [reminder.id,
                reminder.ticket,
                reminder.bp,
                reminder.email,
                reminder.times_sent,
                reminder.created_at.strftime('%Y-%m-%d %H:%M'),
                reminder.updated_at.strftime('%Y-%m-%d %H:%M'),
                reminder.is_active?]
      end
    end
  end

  def self.try_deactivate(params)
    reminder = Reminder.find_by_ticket(params[:ticket])
    unless reminder.nil?
      reminder.active = false
      reminder.save
    end
  end

  # Instance methods
  def send_email_or_cancel
    limit = Parameter.find_by_key('DAYS_BEFORE_CANCEL_TICKET').try('value') || 10
    limit = (limit.to_i > 0)? limit.to_i : 10

    created = self.created_at.to_i
    now = DateTime.now.to_i
    days_elapsed = (now - created) / (24 * 60 * 60)

    if days_elapsed >= limit
      self.active = 0
      self.cancel_remote_ticket(self.ticket)
    else
      self.send_link({
        ticket: self.ticket,
        email: self.email,
        bp: self.bp
      })

      self.times_sent += 1
    end

    self.save
  end

  # Override to_s method
  def to_s
    ticket  # editable
  end

  def cancel_remote_ticket(ticket)
    CancelTicketWorker.perform_async(self.ticket)
  end

  def send_link(params)
    ReminderMailer.delay.send_reminder(params)
  end

  # Get active representation
  def is_active?
    if self.active == 1
      return I18n.t('boolean_true', scope: [:activerecord, :others])
    else
      return I18n.t('boolean_false', scope: [:activerecord, :others])
    end
  end

  private
    def default_values
      self.active ||= 1
      self.times_sent ||= 1
    end
end
