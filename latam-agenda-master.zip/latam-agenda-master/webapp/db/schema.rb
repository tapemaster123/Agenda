# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160603030145) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "case_states", force: :cascade do |t|
    t.integer  "state_id"
    t.integer  "case_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "case_states", ["case_id"], name: "index_case_states_on_case_id", using: :btree
  add_index "case_states", ["state_id"], name: "index_case_states_on_state_id", using: :btree

  create_table "cases", force: :cascade do |t|
    t.string   "ticket",                    limit: 255
    t.datetime "created_at",                            null: false
    t.datetime "updated_at",                            null: false
    t.string   "bp"
    t.string   "email"
    t.string   "ws_user_bp"
    t.string   "ws_user_fullname"
    t.string   "ws_user_type"
    t.string   "ws_user_country"
    t.string   "ws_user_site"
    t.string   "ws_user_phone"
    t.string   "ws_user_annex"
    t.text     "ws_ticket_description"
    t.text     "ws_ticket_detail"
    t.string   "ws_ticket_type"
    t.string   "ws_ticket_aperture_date"
    t.string   "ws_ticket_status"
    t.string   "ws_ticket_resolutor_group"
    t.string   "ws_ticket_analyst"
    t.string   "ws_ticket_analyst_email"
  end

  create_table "countries", force: :cascade do |t|
    t.string "name",       limit: 255
    t.string "alpha_code", limit: 3
  end

  create_table "kiosko_users", force: :cascade do |t|
    t.boolean  "active",     default: true
    t.integer  "kiosko_id"
    t.integer  "user_id"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
  end

  add_index "kiosko_users", ["kiosko_id"], name: "index_kiosko_users_on_kiosko_id", using: :btree
  add_index "kiosko_users", ["user_id"], name: "index_kiosko_users_on_user_id", using: :btree

  create_table "kioskos", force: :cascade do |t|
    t.string   "name",       limit: 255
    t.boolean  "enabled",                default: true
    t.integer  "country_id"
    t.datetime "created_at",                            null: false
    t.datetime "updated_at",                            null: false
    t.string   "map_url"
    t.string   "address"
    t.string   "location"
  end

  add_index "kioskos", ["country_id"], name: "index_kioskos_on_country_id", using: :btree

  create_table "observations", force: :cascade do |t|
    t.text     "observation"
    t.integer  "case_id"
    t.integer  "user_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "submit"
  end

  add_index "observations", ["case_id"], name: "index_observations_on_case_id", using: :btree
  add_index "observations", ["user_id"], name: "index_observations_on_user_id", using: :btree

  create_table "parameters", force: :cascade do |t|
    t.string   "key",        limit: 255
    t.string   "value",      limit: 255
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "reminders", force: :cascade do |t|
    t.string   "ticket",     limit: 255
    t.string   "bp",         limit: 255
    t.string   "email",      limit: 255
    t.integer  "times_sent"
    t.integer  "active"
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "schedules", force: :cascade do |t|
    t.date     "date"
    t.time     "start"
    t.time     "end"
    t.integer  "kiosko_user_id"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.integer  "taken"
    t.integer  "taken_sometime"
  end

  add_index "schedules", ["kiosko_user_id"], name: "index_schedules_on_kiosko_user_id", using: :btree

  create_table "schedulings", force: :cascade do |t|
    t.integer  "schedule_id"
    t.integer  "case_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "active"
  end

  add_index "schedulings", ["case_id"], name: "index_schedulings_on_case_id", using: :btree
  add_index "schedulings", ["schedule_id"], name: "index_schedulings_on_schedule_id", using: :btree

  create_table "states", force: :cascade do |t|
    t.string  "name",                     limit: 255
    t.boolean "terminal"
    t.string  "remote_status"
    t.string  "remote_resolution_method"
  end

  create_table "users", force: :cascade do |t|
    t.string   "firstname",              limit: 255
    t.string   "lastname",               limit: 255
    t.string   "email",                              default: "",   null: false
    t.string   "bp",                     limit: 255
    t.boolean  "enabled",                            default: true
    t.integer  "role"
    t.datetime "created_at",                                        null: false
    t.datetime "updated_at",                                        null: false
    t.string   "encrypted_password",                 default: "",   null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                      default: 0,    null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet     "current_sign_in_ip"
    t.inet     "last_sign_in_ip"
    t.integer  "country_id"
  end

  add_index "users", ["country_id"], name: "index_users_on_country_id", using: :btree
  add_index "users", ["email"], name: "index_users_on_email", unique: true, using: :btree
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree

  add_foreign_key "case_states", "cases"
  add_foreign_key "case_states", "states"
  add_foreign_key "kiosko_users", "kioskos"
  add_foreign_key "kiosko_users", "users"
  add_foreign_key "kioskos", "countries"
  add_foreign_key "observations", "cases"
  add_foreign_key "observations", "users"
  add_foreign_key "schedules", "kiosko_users"
  add_foreign_key "schedulings", "cases"
  add_foreign_key "schedulings", "schedules"
  add_foreign_key "users", "countries"
end
