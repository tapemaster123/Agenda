class CreateCountries < ActiveRecord::Migration
  def change
    create_table :countries do |t|
      t.string :name, limit: 255
      t.string :alpha_code, limit: 3
    end
  end
end
