class AddBpToCases < ActiveRecord::Migration
  def change
    add_column :cases, :bp, :string
  end
end
