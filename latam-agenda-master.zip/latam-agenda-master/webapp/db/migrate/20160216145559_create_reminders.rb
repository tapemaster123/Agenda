class CreateReminders < ActiveRecord::Migration
  def change
    create_table :reminders do |t|
      t.string :ticket, limit: 255
      t.string :bp, limit: 255
      t.string :email, limit: 255
      t.integer :times_sent
      t.integer :active

      t.timestamps null: false
    end
  end
end
