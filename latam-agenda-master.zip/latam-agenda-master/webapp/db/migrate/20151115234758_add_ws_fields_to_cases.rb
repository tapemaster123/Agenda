class AddWsFieldsToCases < ActiveRecord::Migration
  def change
    add_column :cases, :ws_user_bp, :string
    add_column :cases, :ws_user_fullname, :string
    add_column :cases, :ws_user_type, :string
    add_column :cases, :ws_user_country, :string
    add_column :cases, :ws_user_site, :string
    add_column :cases, :ws_user_phone, :string
    add_column :cases, :ws_user_annex, :string
    add_column :cases, :ws_ticket_description, :text
    add_column :cases, :ws_ticket_detail, :text
    add_column :cases, :ws_ticket_type, :string
    add_column :cases, :ws_ticket_aperture_date, :string
    add_column :cases, :ws_ticket_status, :string
    add_column :cases, :ws_ticket_resolutor_group, :string
    add_column :cases, :ws_ticket_analyst, :string
  end
end
