class CreateObservations < ActiveRecord::Migration
  def change
    create_table :observations do |t|
      t.text :observation
      t.references :case, index: true, foreign_key: true
      t.references :user, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
