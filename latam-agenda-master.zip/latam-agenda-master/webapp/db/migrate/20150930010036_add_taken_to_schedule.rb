class AddTakenToSchedule < ActiveRecord::Migration
  def change
    add_column :schedules, :taken, :integer
  end
end
