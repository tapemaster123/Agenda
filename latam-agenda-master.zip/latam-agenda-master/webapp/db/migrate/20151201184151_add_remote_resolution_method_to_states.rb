class AddRemoteResolutionMethodToStates < ActiveRecord::Migration
  def change
    add_column :states, :remote_resolution_method, :string

    state = State.try(:find_by_name, 'Abierto')
    state.remote_resolution_method = '' unless state.nil?
    state.save! unless state.nil?

    state = State.try(:find_by_name, 'Resuelto - Nivel 2')
    state.remote_resolution_method = 'Resuelto por N2' unless state.nil?
    state.save! unless state.nil?

    state = State.try(:find_by_name, 'Cerrado - Sin Respuesta Usuario')
    state.remote_resolution_method = 'Cerrado - Sin Respuesta Usuario' unless state.nil?
    state.save! unless state.nil?

    state = State.try(:find_by_name, 'Agendamiento Cerrado')
    state.remote_resolution_method = '' unless state.nil?
    state.save! unless state.nil?
  end
end
