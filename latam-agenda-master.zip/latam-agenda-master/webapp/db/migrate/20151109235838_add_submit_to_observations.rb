class AddSubmitToObservations < ActiveRecord::Migration
  def change
    add_column :observations, :submit, :integer
  end
end
