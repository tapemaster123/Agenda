class AddMapUrlToKioskos < ActiveRecord::Migration
  def change
    add_column :kioskos, :map_url, :string
  end
end
