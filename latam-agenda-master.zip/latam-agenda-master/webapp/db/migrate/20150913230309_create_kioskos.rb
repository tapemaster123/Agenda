class CreateKioskos < ActiveRecord::Migration
  def change
    create_table :kioskos do |t|
      t.string :name, limit: 255
      t.boolean :enabled, default: :true
      t.references :country, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
