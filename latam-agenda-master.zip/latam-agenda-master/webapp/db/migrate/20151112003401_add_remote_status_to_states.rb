class AddRemoteStatusToStates < ActiveRecord::Migration
  def change
    add_column :states, :remote_status, :string
  end
end
