class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :firstname, limit: 255
      t.string :lastname, limit: 255
      t.string :email, null: false, default: ""
      t.string :bp, limit: 255
      t.boolean :enabled, default: :true
      t.integer :role, limit: 4

      t.timestamps null: false
    end
  end
end
