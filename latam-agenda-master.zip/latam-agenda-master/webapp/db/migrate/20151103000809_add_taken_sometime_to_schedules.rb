class AddTakenSometimeToSchedules < ActiveRecord::Migration
  def change
    add_column :schedules, :taken_sometime, :integer
  end
end
