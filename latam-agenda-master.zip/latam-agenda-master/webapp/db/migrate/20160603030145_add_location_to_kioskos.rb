class AddLocationToKioskos < ActiveRecord::Migration
  def change
    add_column :kioskos, :location, :string
  end
end
