class AddWsTicketAnalystEmailToCases < ActiveRecord::Migration
  def change
    add_column :cases, :ws_ticket_analyst_email, :string
  end
end
