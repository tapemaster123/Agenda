class CreateSchedules < ActiveRecord::Migration
  def change
    create_table :schedules do |t|
      t.date :date
      t.time :start
      t.time :end
      t.references :kiosko_user, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
