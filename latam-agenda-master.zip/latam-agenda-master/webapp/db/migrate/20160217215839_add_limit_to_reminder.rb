class AddLimitToReminder < ActiveRecord::Migration
  def change
    parameter = Parameter.find_by_key('DAYS_BEFORE_CANCEL_TICKET').try('value')

    if parameter.nil?
      Parameter.create! key: 'DAYS_BEFORE_CANCEL_TICKET', value: '10'
    end
  end
end
