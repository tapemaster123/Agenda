class AddActiveToScheduling < ActiveRecord::Migration
  def change
    add_column :schedulings, :active, :integer
  end
end
