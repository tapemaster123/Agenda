class CreateCaseStates < ActiveRecord::Migration
  def change
    create_table :case_states do |t|
      t.references :state, index: true, foreign_key: true
      t.references :case, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
