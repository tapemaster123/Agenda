#encoding: utf-8
# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).

# Clean tables
Scheduling.delete_all
Observation.delete_all
Schedule.delete_all
KioskoUser.delete_all
Kiosko.delete_all
User.delete_all
CaseState.delete_all
State.delete_all
Case.delete_all
Country.delete_all
Parameter.delete_all

# Reset postgres auto increments
CaseState.connection.execute('ALTER SEQUENCE case_states_id_seq RESTART WITH 1')
Observation.connection.execute('ALTER SEQUENCE observations_id_seq RESTART WITH 1')
Scheduling.connection.execute('ALTER SEQUENCE schedulings_id_seq RESTART WITH 1')
State.connection.execute('ALTER SEQUENCE states_id_seq RESTART WITH 1')
Case.connection.execute('ALTER SEQUENCE cases_id_seq RESTART WITH 1')
Schedule.connection.execute('ALTER SEQUENCE schedules_id_seq RESTART WITH 1')
KioskoUser.connection.execute('ALTER SEQUENCE kiosko_users_id_seq RESTART WITH 1')
Kiosko.connection.execute('ALTER SEQUENCE kioskos_id_seq RESTART WITH 1')
Country.connection.execute('ALTER SEQUENCE countries_id_seq RESTART WITH 1')
User.connection.execute('ALTER SEQUENCE users_id_seq RESTART WITH 1')
Parameter.connection.execute('ALTER SEQUENCE parameters_id_seq RESTART WITH 1')

# Countries
country_CL = Country.create! name: 'Chile', alpha_code: 'CL'
country_AR = Country.create! name: 'Argentina', alpha_code: 'AR'
country_CO = Country.create! name: 'Colombia', alpha_code: 'CO'
country_PE = Country.create! name: 'Perú', alpha_code: 'PE'
country_US = Country.create! name: 'Estados Unidos', alpha_code: 'US'
country_EC = Country.create! name: 'Ecuador', alpha_code: 'EC'
country_PY = Country.create! name: 'Paraguay', alpha_code: 'PY'
country_BR = Country.create! name: 'Brasil', alpha_code: 'BR'

# Users
user_0 = User.create! firstname: 'Accenture', lastname: 'Admin', email:'latam.agenda.admin@accenture.com', password:'latamagendaadmin2017', password_confirmation:'latamagendaadmin2017', role: 0, bp: 123456, enabled: true, country: country_CL

user_1 = User.create! firstname: 'System', lastname: 'Admin', email:'admin@requies.cl', password:'admin123', password_confirmation:'admin123', role: 0, bp: 123456, enabled: true, country: country_CL
user_2 = User.create! firstname: 'Caio', lastname: 'Bezares', email:'caio@requies.cl', password:'caio123', password_confirmation:'caio123', role: 0, bp: 234567, enabled: true, country: country_CL
user_3 = User.create! firstname: 'Danilo', lastname: 'Aburto', email:'danilo@requies.cl', password: 'danilo123', password_confirmation:'danilo123', role: 0, bp: 345678, enabled: true, country: country_CL

# BORRAR
# user_4 = User.create! firstname: 'Manager', lastname: 'Uno', email:'manager1@requies.cl', password: 'manager1', password_confirmation: 'manager1', role: 10, bp: 901234, enabled: true, country: country_CL
# user_5 = User.create! firstname: 'Manager', lastname: 'Dos', email:'manager2@requies.cl', password: 'manager2', password_confirmation: 'manager2', role: 10, bp: 012345, enabled: true, country: country_CL
# user_6 = User.create! firstname: 'Juan', lastname: 'Técnico', email:'juan.tecnico@accenture.com', password: 'admin123', password_confirmation: 'admin123', role: 20, bp: 456789, enabled: true, country: country_CL
# user_7 = User.create! firstname: 'Javier', lastname: 'Técnico', email:'javier.tecnico@accenture.com', password: 'admin123', password_confirmation: 'admin123', role: 20, bp: 567890, enabled: true, country: country_CL
# user_8 = User.create! firstname: 'Mesa', lastname: 'De ayuda', email:'mda@accenture.com', password: 'admin123', password_confirmation: 'admin123', role: 30, bp: 678901, enabled: true, country: country_CL
# user_9 = User.create! firstname: 'Pedro', lastname: 'Asistente', email:'pedro.asistente@accenture.com', password: 'admin123', password_confirmation: 'admin123', role: 30, bp: 789012, enabled: true, country: country_CL
# user_10 = User.create! firstname: 'Carlos', lastname: 'Asistente', email:'carlos.asistente@accenture.com', password: 'admin123', password_confirmation: 'admin123', role: 30, bp: 890123, enabled: true, country: country_CL

# Kioskos
kiosko_1 = Kiosko.create! name: 'Edificio Corporativo', enabled: true, country: country_CL
kiosko_2 = Kiosko.create! name: 'Base Mantenimiento', enabled: true, country: country_CL
kiosko_3 = Kiosko.create! name: 'Estado 10', enabled: true, country: country_CL
kiosko_4 = Kiosko.create! name: 'Huidobro', enabled: true, country: country_CL
kiosko_5 = Kiosko.create! name: 'Costa Salguero', enabled: true, country: country_AR
kiosko_6 = Kiosko.create! name: 'Edificio Corporativo', enabled: true, country: country_CO
kiosko_7 = Kiosko.create! name: 'Aeropuerto', enabled: true, country: country_CO
kiosko_8 = Kiosko.create! name: 'Edificio Corporativo', enabled: true, country: country_PE
kiosko_9 = Kiosko.create! name: 'Aeropuerto', enabled: true, country: country_PE
kiosko_10 = Kiosko.create! name: 'Edificio Corporativo', enabled: true, country: country_US
kiosko_11 = Kiosko.create! name: 'Quito', enabled: true, country: country_EC
kiosko_12 = Kiosko.create! name: 'Guayaquil', enabled: true, country: country_EC
kiosko_13 = Kiosko.create! name: 'Asunción', enabled: true, country: country_PY

# KioskoUsers
# KioskoUser.create! user: user_4, kiosko: kiosko_1, active: true
# KioskoUser.create! user: user_4, kiosko: kiosko_2, active: true
# KioskoUser.create! user: user_5, kiosko: kiosko_2, active: true
# KioskoUser.create! user: user_5, kiosko: kiosko_3, active: true

# KioskoUser.create! user: user_6, kiosko: kiosko_1, active: true
# KioskoUser.create! user: user_7, kiosko: kiosko_2, active: true
# KioskoUser.create! user: user_8, kiosko: kiosko_3, active: true

# States
# State.create! name: 'Abierto', terminal: false
# State.create! name: 'En curso', terminal: false
# State.create! name: 'Resuelto', terminal: true
# State.create! name: 'Cancelado', terminal: true

State.create!(
  name: 'Abierto',
  remote_status: 'Pendiente - Acción Usuario',
  remote_resolution_method: '',
  terminal: false
)

State.create!(
  name: 'Resuelto - Nivel 2',
  remote_status: 'Resuelto - Nivel 2',
  remote_resolution_method: 'Resuelto por N2',
  terminal: true
)

State.create!(
  name: 'Cerrado - Sin Respuesta Usuario',
  remote_status: 'Cerrado - Sin Respuesta Usuario',
  remote_resolution_method: 'Cerrado - Sin Respuesta Usuario',
  terminal: true
)

State.create!(
  name: 'Agendamiento Cerrado',
  remote_status: 'Asignado',
  remote_resolution_method: '',
  terminal: true
)

# State.create!(
#   name: 'Agendamiento Cerrado',
#   remote_status: 'En Progreso',
#   remote_resolution_method: '',
#   terminal: true
# )

# Parameters
Parameter.create! key: 'WS_WSDL', value: 'http://latam-cervellowebservices.accenture.com/webservicev3/Integracao.asmx?WSDL'
Parameter.create! key: 'WS_ENV_NAMESPACE', value: 'soapenv'
Parameter.create! key: 'WS_NAMESPACE_IDENTIFIER', value: 'tem'

Parameter.create! key: 'SMTP_ADDRESS', value: '57.228.128.81'
Parameter.create! key: 'SMTP_PORT', value: '25'
Parameter.create! key: 'SMTP_USER_NAME', value: 'agenda.kiosco.it'
Parameter.create! key: 'SMTP_PASSWORD', value: 'Accenture.kiosco'

Parameter.create! key: 'DAYS_BEFORE_CANCEL_TICKET', value: '3'
