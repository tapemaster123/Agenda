#!/bin/bash

# Remote credentials
USER=server_user
HOST=server_ip
PROJECT_PATH=/path/to/project
REMOTE_NAME=server_name

# Command
COMMAND=$1

if [ "$COMMAND" = "setup" ]
then
    # Si existe una llave ssh local
    if [ -f ~/.ssh/id_rsa.pub ]; then

        # Se ejecuta remotamente el script para establecer comunicacion sin password
        ssh $USER@$HOST "bash -s" < ./scripts/remote/setup-ssh.sh $(cat ~/.ssh/id_rsa.pub)
    fi

    # Se ejecuta remotamente el script de inicializacion
    ssh $USER@$HOST "bash -s" < ./scripts/remote/setup-repo.sh $PROJECT_PATH

    # Se define localmente el repositorio remoto para produccion
    git remote add $REMOTE_NAME ssh://$USER@$HOST:$PROJECT_PATH/.git

elif [ "$COMMAND" = "transfer" ]
then
    git push --force $REMOTE_NAME master

else
    echo "Comando desconocido"
fi
