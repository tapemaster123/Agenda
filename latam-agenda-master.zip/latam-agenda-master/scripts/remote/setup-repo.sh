#!/bin/bash

##
# Verifica que el directorio y repositorio asociado existan.
# En caso de no existir crea el directorio e inicializa el repo.
##

PROJECT_PATH=$1

# Si no existe el proyecto se crea el directorio
mkdir -p $PROJECT_PATH;

# Si no hay un repositorio creado se crea
if [ ! -d "$PROJECT_PATH/.git" ]; then 
    git init $PROJECT_PATH;

    # Se configura git para recibir push en repositorios non-bare
    # https://github.com/blog/1957-git-2-3-has-been-released    
    cd $PROJECT_PATH
    git config receive.denyCurrentBranch updateInstead
fi