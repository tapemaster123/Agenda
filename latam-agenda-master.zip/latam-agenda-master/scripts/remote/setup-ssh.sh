#!/bin/bash

##
# Agrega al listado de llaves ssh autorizadas una 
# llave pasada por parámetro
##

# Argumento completo (previene separar varios argumentos cuando hay espacios)
KEY="$*"

# Existe el directorio .ssh?
if [ ! -d "~/.ssh" ]; then 
    mkdir -p ~/.ssh
fi

# Existe el archivo de llaves autorizadas?
if [ ! -f ~/.ssh/authorized_keys ]; then
    touch ~/.ssh/authorized_keys
fi

# Si la llave no está en el listado, entonces se agrega
if [ -z "$(grep "$KEY" ~/.ssh/authorized_keys )" ]; then 
    echo $KEY >> ~/.ssh/authorized_keys; 
    echo key added!; 
fi;