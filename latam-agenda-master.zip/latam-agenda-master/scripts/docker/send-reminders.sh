#!/bin/bash

# Si la variable no existe, entonces se define
if [ -z ${PROJECT_PATH+x} ]; then PROJECT_PATH=/home/app; fi

cd $PROJECT_PATH/webapp && RAILS_ENV=production bundle exec rake latam:send_reminders
