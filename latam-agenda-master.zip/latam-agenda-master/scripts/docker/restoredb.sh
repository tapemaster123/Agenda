#!/bin/bash

# Si la variable no existe, entonces se define
if [ -z ${PROJECT_PATH+x} ]; then PROJECT_PATH=/home/app; fi

# Se verifica que exista el directorio para logs
mkdir -p $PROJECT_PATH/persistent/log/restoredb

# Se eliminan las conexiones activas a la base de datos
echo "Despojando conexiones" >> $PROJECT_PATH/persistent/log/restoredb/`date +\%Y-\%m-\%d`.txt
psql -h db -U postgres -c "SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = 'latam_agenda' AND pid <> pg_backend_pid();" >> $PROJECT_PATH/persistent/log/restoredb/`date +\%Y-\%m-\%d`.txt 2>&1

# Se realiza la restauracion
# Se deja en log solo el stderr
gunzip --stdout --suffix zip $PROJECT_PATH/persistent/backups/db/$1 | psql -h db -U postgres > /dev/null 2>> $PROJECT_PATH/persistent/log/restoredb/`date +\%Y-\%m-\%d`.txt
