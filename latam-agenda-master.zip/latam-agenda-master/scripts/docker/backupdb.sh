#!/bin/bash

# Constantes
DB_NAME=latam_agenda

# Si la variable no existe, entonces se define
if [ -z ${PROJECT_PATH+x} ]; then PROJECT_PATH=/home/app; fi

# Se verifica que exista el directorio de respaldo
mkdir -p $PROJECT_PATH/persistent/backups/db

# Se realiza el respaldo de la base de datos
# El respalo es almacenado en un archivo con persistencia fuera del contenedor
pg_dump --compress=6 --no-owner --create --clean -h db -U postgres $DB_NAME -f $PROJECT_PATH/persistent/backups/db/latam-agenda-`date +\%Y\%m\%d-\%H\%M\%S`.zip
