#!/bin/bash

##
# Este script esta construido para ser ejecutado
# al interior de un contenedor docker
##

##
# Variables
##
ARG1=$1
PROJECT_PATH=/home/app

# Respaldo de BD
echo "Respaldando base de datos..."
source $PROJECT_PATH/scripts/docker/backupdb.sh

# Limpieza
echo "Ejecutando limpieza..."
source $PROJECT_PATH/scripts/docker/clean.sh
