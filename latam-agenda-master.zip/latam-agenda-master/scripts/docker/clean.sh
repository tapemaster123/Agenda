#!/bin/bash

# Si la variable no existe, entonces se define
if [ -z ${PROJECT_PATH+x} ]; then PROJECT_PATH=/home/app; fi

BACKUP_DIR="$PROJECT_PATH/persistent/backups/db"
LOG_RESTOREDB_DIR="$PROJECT_PATH/persistent/log/restoredb"

# Se verifica que el directorio exista para que find no falle
mkdir -p $BACKUP_DIR
mkdir -p $LOG_RESTOREDB_DIR

# Se remueven respaldos con antiguedad mayor a 30 dias
OLD=$(find $BACKUP_DIR -type f -mtime +30)
if [ -n "$OLD" ] ; then
    echo deleting old backup files: $OLD
    echo $OLD | xargs rm -rfv
fi

OLD=$(find $LOG_RESTOREDB_DIR -type f -mtime +30)
if [ -n "$OLD" ] ; then
    echo deleting old restoredb log files: $OLD
    echo $OLD | xargs rm -rfv
fi
